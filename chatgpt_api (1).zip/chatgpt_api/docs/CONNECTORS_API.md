# ChatGPT Connectors API - Reverse Engineered

## Overview

ChatGPT connectors are third-party integrations (Google Drive, GitHub, Slack, etc.) and first-party tools (Deep Research, Web Search, DALL-E, etc.) that extend ChatGPT's capabilities.

## How Connectors Work

1. **First-Party Tools** - Built-in tools that don't require OAuth:
   - `search` - Web search
   - `dalle` / `picture_v2` - Image generation
   - `code_interpreter` - Code execution
   - `canvas` - Document editing
   - `thinking` - Extended thinking mode
   - `connector:connector_openai_deep_research` - Deep research

2. **Third-Party Connectors** - Require OAuth linking:
   - Google Drive, GitHub, Notion, Slack, Asana, etc.
   - User must complete OAuth flow once
   - Then connector becomes available in conversations

## API Endpoints

### List Connectors

```
POST /backend-api/aip/connectors/list_accessible
Query params: skip_actions=true&external_logos=true&skip_directory=true
Body: {}

Response:
{
  "connectors": [
    {
      "id": "connector_68df33b1a2d081918778431a9cfca8ba",
      "name": "GitHub",
      "description": "...",
      "connector_type": "SERVICE",
      "supported_auth": [{"type": "OAUTH"}],
      "actions": [...],
      ...
    }
  ]
}
```

### List User's Linked Connectors

```
POST /backend-api/aip/connectors/links/list_accessible
Body: {"principals": []}

Response:
{
  "links": [
    {
      "id": "link_xxx",
      "connector_id": "connector_xxx",
      "name": "GitHub",
      "auth_status": "ACTIVE",
      "actions": ["search_repos", "get_file", ...],
      ...
    }
  ]
}
```

### Start OAuth Flow

```
POST /backend-api/aip/connectors/links/oauth
Body: {
  "connector_id": "connector_68df33b1a2d081918778431a9cfca8ba",
  "callback_url": "com.openai.chatgpt://auth.openai.com/android/com.openai.chatgpt/aip/{connector_id}/oauth/callback"
}

Response:
{
  "redirect_url": "https://github.com/login/oauth/authorize?...",
  "email_challenge_sent": false
}
```

### Verify OAuth Callback

```
POST /backend-api/aip/connectors/links/oauth/verification
Body: {
  "connector_id": "connector_xxx",
  "callback_url": "...?code=xxx&state=xxx"
}

Response:
{
  "success": true,
  "link_id": "link_xxx"
}
```

### Get Connector Details

```
GET /backend-api/aip/connectors/{connector_id}?include_logo=false&include_actions=true

Response:
{
  "id": "connector_xxx",
  "name": "GitHub",
  "actions": [
    {"name": "search_repos", "description": "..."},
    {"name": "get_file_content", "description": "..."},
    ...
  ]
}
```

### Get Connector Actions

```
GET /backend-api/aip/connectors/{connector_id}/actions

Response:
{
  "actions": [
    {"name": "search_repos", "parameters": {...}},
    ...
  ]
}
```

### Other Endpoints

```
GET  /backend-api/aip/connectors/{connector_id}/link - Get user's link for connector
POST /backend-api/aip/connectors/links/api_key - Link with API key
POST /backend-api/aip/connectors/links/noauth - Link without auth
POST /backend-api/aip/connectors/links/oauth/reauth - Re-authenticate
PATCH /backend-api/aip/connectors/links/{link_id} - Update link settings
DELETE /backend-api/aip/connectors/{connector_id} - Delete/unlink connector
```

## Using Connectors in Conversations

To use a connector in a conversation, add `system_hints` to the conversation payload:

```json
{
  "action": "next",
  "messages": [...],
  "model": "auto",
  "system_hints": ["connector:connector_68df33b1a2d081918778431a9cfca8ba"],
  ...
}
```

### First-Party Tool Hints

```json
"system_hints": ["search"]           // Web search
"system_hints": ["dalle"]            // Image generation
"system_hints": ["picture_v2"]       // Image generation (v2)
"system_hints": ["code_interpreter"] // Code execution
"system_hints": ["canvas"]           // Document editing
"system_hints": ["thinking"]         // Extended thinking
"system_hints": ["connector:connector_openai_deep_research"] // Deep research
```

### Third-Party Connector Hints

```json
"system_hints": ["connector:connector_68df33b1a2d081918778431a9cfca8ba"] // GitHub
"system_hints": ["connector:connector_2128aebfecb84f64a069897515042a44"] // Google Drive
```

## Known Connector IDs

| Name | Connector ID |
|------|-------------|
| Deep Research | connector_openai_deep_research |
| GitHub | connector_68df33b1a2d081918778431a9cfca8ba |
| Google Drive | connector_2128aebfecb84f64a069897515042a44 |
| Notion | connector_76869538009648d5b282a4bb21c3d157 |
| Slack | connector_b969d12728c04baeb585eb9299be3b6d |
| Asana | connector_2b0a9009c9c64bf9933a3dae3f2b1254 |
| Linear | connector_0c9786b2f41f41558056126bdb46c9bd |
| Jira | connector_14e85e16800b4e53bc6246019a83a307 |
| Confluence | connector_2fc94c70cbb74b7caa6d07bf7231202e |
| HubSpot | connector_2a3c0c472f6f4238b47d41acfb317307 |
| Salesforce | connector_9f3d361ec84b4c6588a7129a2d4e3cb3 |
| Zendesk | connector_f9447fe87aae4b598f8ca9dc03483c9a |
| Dropbox | connector_4886707321be47efb8b9369ebb877881 |
| Box | connector_251970f16cb647d4b76fc445753f9276 |
| OneDrive | connector_da257d66000a45c683fe44e411037409 |
| SharePoint | connector_4d2f184d2773465f977823d8d03a059a |
| OpenAI Platform | connector_2de447f3f15448ebab48783d7e4f5d81 |

## Proxy API Endpoints

The `chatgpt_proxy_api.py` server exposes these connector endpoints:

```
GET  /v1/connectors           - List available tools/connectors (static list)
POST /v1/connectors/list      - List all connectors from API
POST /v1/connectors/links     - List user's linked connectors
POST /v1/connectors/oauth/start  - Start OAuth flow
POST /v1/connectors/oauth/verify - Verify OAuth callback
```

### Example: Start OAuth for GitHub

```bash
curl -X POST http://localhost:8080/v1/connectors/oauth/start \
  -H "Content-Type: application/json" \
  -d '{"connector_id": "connector_68df33b1a2d081918778431a9cfca8ba"}'
```

### Example: Chat with Web Search

```bash
curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4o",
    "messages": [{"role": "user", "content": "What are the latest AI news today?"}],
    "tools": ["web_search"]
  }'
```

### Example: Chat with Deep Research

```bash
curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4o",
    "messages": [{"role": "user", "content": "Do deep research on quantum computing advances"}],
    "tools": ["deep_research"]
  }'
```

## Cross-Device OAuth Flow (Without Mobile App)

The standard ChatGPT OAuth flow uses a popup window with postMessage to communicate the result. However, we can bypass this by using a local callback server:

### Flow Overview

1. **Start OAuth**: POST to `/aip/connectors/links/oauth` with connector_id and callback_url
   - Returns `redirect_url` (OAuth provider URL) and `oauth_state_id`

2. **User Authorization**: Open redirect_url in browser, user completes OAuth

3. **Callback Capture**: Third party redirects to callback_url with `code` and `state` params

4. **Verify**: POST to `/aip/connectors/links/oauth/verification` with connector_id and full callback_url (including query params)
   - Returns `link_id` on success

### Standalone Implementation

Use `chatgpt_oauth_flow.py` for a complete standalone OAuth flow:

```bash
# Link Canva connector
python chatgpt_oauth_flow.py --connector canva --token YOUR_ACCESS_TOKEN

# List linked connectors
python chatgpt_oauth_flow.py --list --token YOUR_ACCESS_TOKEN

# List available connectors
python chatgpt_oauth_flow.py --available --token YOUR_ACCESS_TOKEN
```

### API Details

**Start OAuth Request:**
```json
POST /backend-api/aip/connectors/links/oauth
{
  "connector_id": "connector_f2cc2728d79f4d5e94d9628ee8fce62c",
  "callback_url": "http://localhost:9876/oauth/callback"
}
```

**Start OAuth Response:**
```json
{
  "redirect_url": "https://www.canva.com/oauth/authorize?...",
  "oauth_state_id": "oauthstate_xxx",
  "email_challenge_sent": false
}
```

**Verify OAuth Request:**
```json
POST /backend-api/aip/connectors/links/oauth/verification
{
  "connector_id": "connector_f2cc2728d79f4d5e94d9628ee8fce62c",
  "callback_url": "http://localhost:9876/oauth/callback?code=xxx&state=xxx"
}
```

**Verify OAuth Response:**
```json
{
  "link_id": "link_xxx",
  "success": true
}
```

### Key Findings

1. The callback URL doesn't need to be the mobile deep link - any URL works
2. The `oauth_state_id` is embedded in the OAuth state parameter
3. Verification works by passing the full callback URL with query params
4. Once linked, the connector persists across devices

## Notes

1. Third-party connectors require OAuth linking first - you must complete the OAuth flow once in a browser.

2. First-party tools (search, dalle, etc.) work without OAuth but may require a Plus subscription.

3. Some connectors may show a confirmation dialog in the UI before executing actions - this is handled by `jit_plugin_data` with `type: "confirm_action"` in the SSE stream.

4. The `allow_read_actions_without_confirmation` field determines if read-only actions can run without user confirmation.

5. **Cross-device usage**: Once a connector is linked via OAuth, it's associated with your account and works from any device using the same access token.
