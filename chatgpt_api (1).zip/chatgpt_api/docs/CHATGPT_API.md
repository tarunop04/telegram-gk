# ChatGPT Web API Documentation

Generated: 2026-05-30T21:11:23.791Z

## Authentication

ChatGPT uses Bearer token authentication. The access token is obtained after login
and sent in the `Authorization` header.

```
Authorization: Bearer <access_token>
```

## Captured Endpoints

### GET /backend-anon/accounts/check/v4-2023-04-27

**Method:** GET

**Response:**
```json
{
  "accounts": {
    "default": {
      "account": {
        "account_user_role": "account-owner",
        "account_user_id": null,
        "account_owner_id": null,
        "account_residency_region": "no_constraint",
        "account_compute_residency": "no_constraint",
        "account_compute_residency_display_name": "No Constraint",
        "account_compute_residency_description": "No inference residency constraints",
        "processor": {
          "a001": {
            "has_customer_obj
```

---

### GET /backend-anon/me

**Method:** GET

**Response:**
```json
{
  "object": "",
  "id": "ua-2a0328f6-b4a7-495b-9819-f53e713f721c",
  "email": "",
  "name": "",
  "picture": "",
  "created": 1780175153,
  "phone_number": "",
  "email_domain_type": "unknown",
  "country": "IN",
  "region": "Uttar Pradesh",
  "region_code": "UP"
}
```

---

### POST /backend-anon/sentinel/chat-requirements/prepare

**Method:** POST

**Response:**
```json
{
  "persona": "chatgpt-noauth",
  "prepare_token": "gAAAAABqG1ExjR0aVIvJLZmh-qGlTFlKjFTflQj-JZbOp7u9gcGRKQoaMNq0xNn6-if7YqDKEaqOwKMMgyBq4ozXzTRZXQcd0n5V-fBEXaZ4o36_opFClgm_GjsitZlBupAH3SnK8AsJlLDiTpF0DOmFFpBr31imZlySvXAA0Zg0mygs6k1FP5w2arLzuYtP80azJ-kllOImNZbOyETcSCzS6ldsc9FWjLi0oqnP99VVYwT4m8ThsQf0S55f04Tpd2dB1pfya_MRw7aF_HqlH2u3w2UG8W4S1KeRITt5v86rbe-jRiB94hL5qH_N4SskZ1pNbSOfogYd3KQg83Thb8-SfwYrb0VQRuh0q4StHn_1w6Gdyo0oJO8Lu9FwOOe-irYcuYQzuw67l5RPTOnXmacI5QkbKXiy94VbUI1yX8V4Z3K_cWQ4gUHt4eJJe4T
```

---

### GET /backend-anon/system_hints

**Method:** GET

**Response:**
```json
{
  "system_hints": [
    {
      "system_hint": "search",
      "name": "Search",
      "description": "Find real-time news and info",
      "action_label": "Web search",
      "short_label": null,
      "logo": "<svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" class=\"\"><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12ZM11.
```

---

### GET /backend-anon/models

**Method:** GET

**Response:**
```json
{
  "title": "ChatGPT",
  "secondary_title": "",
  "models": [
    {
      "slug": "gpt-5-3",
      "max_tokens": 34834,
      "title": "GPT-5.3",
      "description": "Our latest and most advanced model",
      "tags": [
        "history_off_approved"
      ],
      "capabilities": {},
      "product_features": {
        "attachments": {
          "type": "retrieval",
          "accepted_mime_types": [
            "application/x-hwp+zip",
            "text/x-php",
            "application/x-yam
```

---

### POST /backend-anon/sentinel/chat-requirements/finalize

**Method:** POST

**Response:**
```json
{
  "persona": "chatgpt-noauth",
  "token": "gAAAAABqG1Eyh86CKMOHpb0IT0T6KezbjAaJEDDbEHBgcCmtmeD2zZoykRw-so7mjUTCMBNvFnAH1D13T3iAnHEODngT5GZ8SaR_UcS2d1p2CwD9u6Wvt9t0zKKmApZPX2Qf4ZLhlkDvxEp2_QJNkzHK3pL17QHw2BEotQN0m5zna7EbBct98kOz3CRjt_CfyT6N5UArf0ICSqMkzUTAZHAAyhmWJ3AH5IyZ2GKp5MEzIt9wWeTyBLjbTl5lRxi8kuLF828-0kfrOedu8UXqDZzJ6ZRlSyt6otitBpKEzg9tnbonS0wouEQBrGUojep7QeWDNfoe3NjSP-gCUWmFRzuE3DcN-It81ZrkwodXL6HscMxfR1U-I4hKu5SumJw8dn9XbHRslUNjHS8SXTcXs452MAhi_rCq7vAmj6qswe0VUhzgpLzQZdg2NqkJr2xzzEw-sdI
```

---

### POST /backend-anon/conversation/init

**Method:** POST

**Response:**
```json
{
  "type": "conversation_detail_metadata",
  "banner_info": null,
  "blocked_features": [],
  "model_limits": [],
  "limits_progress": [
    {
      "feature_name": "file_upload",
      "remaining": 3,
      "reset_after": "2026-05-31T21:05:54.208592+00:00"
    },
    {
      "feature_name": "paste_text_to_file",
      "remaining": 3,
      "reset_after": "2026-05-31T21:05:54.208611+00:00"
    },
    {
      "feature_name": "dictation",
      "remaining": 1,
      "reset_after": "2026-06-06T21:
```

---

### GET /backend-anon/checkout_pricing_config/countries

**Method:** GET

**Response:**
```json
{
  "countries": [
    "EE",
    "SO",
    "GI",
    "TN",
    "PL",
    "JM",
    "BM",
    "TV",
    "PN",
    "BT",
    "US2",
    "BB",
    "AX",
    "NA",
    "SG",
    "DO",
    "MD",
    "FI",
    "LY",
    "IS",
    "PE",
    "AU",
    "AS",
    "QA",
    "MK",
    "HR",
    "JP",
    "PF",
    "GN",
    "VC",
    "CH",
    "SI",
    "GQ",
    "ID",
    "AQ",
    "AW",
    "SK",
    "MC",
    "TZ",
    "LI",
    "HT",
    "GD",
    "GU",
    "OM",
    "IT",
    "FJ",
    "PW",
    "SH",

```

---

### GET /backend-anon/prompt_library/

**Method:** GET

**Response:**
```json
{
  "items": [
    {
      "id": "58a3e0b6",
      "title": "Summarize",
      "description": "my lease agreement",
      "prompt": "Can you summarize my lease agreement? I want to know the key points and any important clauses. If you need more information, ask me a follow up question or ask me to upload a file or image.",
      "oneliner": "Summarize my lease agreement",
      "category": "file-upload-document",
      "requires_file_upload": true,
      "theme": "Summarize text"
    },
    {
  
```

---

### GET /backend-anon/accounts/passkey/challenge

**Method:** GET

**Response:**
```json
{
  "credential_request_options": {
    "challenge": "FLNIXaiBNbi9OEahCk3ZPQ9qTLP2F-zzqr5J3mI-Mv4",
    "timeout": 600000,
    "rpId": "openai.com",
    "userVerification": "required"
  },
  "mfa_request_id": "6a1b5133a030819189449020d894e7d6",
  "issued_at": 1780175155,
  "signature": "x8HzMnDAXTEjYU6XFeuka5nmFichzme69GjW0uwBpa8"
}
```

---

### GET /backend-anon/checkout_pricing_config/configs/IN

**Method:** GET

**Response:**
```json
{
  "country_code": "IN",
  "currency_config": {
    "free": {
      "month": {
        "tax": "inclusive",
        "amount": 0
      }
    },
    "go": {
      "month": {
        "amount": 399,
        "tax": "inclusive"
      }
    },
    "plus": {
      "month": {
        "amount": 1999,
        "tax": "inclusive",
        "psp_override": {
          "amount": 1694.07,
          "tax": "exclusive"
        }
      }
    },
    "pro": {
      "month": {
        "amount": 19900,
        "tax": "
```

---

### GET /backend-anon/settings/voices

**Method:** GET

**Response:**
```json
{
  "selected": "breeze",
  "voices": [
    {
      "voice": "breeze",
      "name": "Breeze",
      "gain_db": null,
      "preview_url": "https://persistent.oaistatic.com/voice/previews/breeze.en.5fc1dadf.m4a",
      "description": "Animated and earnest",
      "bloop_color": "808080"
    },
    {
      "voice": "maple",
      "name": "Maple",
      "gain_db": null,
      "preview_url": "https://persistent.oaistatic.com/voice/previews/maple.en.abff11d0.m4a",
      "description": "Cheerful and 
```

---

### GET https://sentinel.openai.com/backend-api/sentinel/sdk.js

**Method:** GET

---

### GET https://sentinel.openai.com/backend-api/sentinel/frame.html

**Method:** GET

---

### POST https://sentinel.openai.com/backend-api/sentinel/req

**Method:** POST

**Request Body:**
```json
{
  "p": "gAAAAACWzIzNDAsIlN1biBNYXkgMzEgMjAyNiAwMjozNjoyMyBHTVQrMDUzMCAoSW5kaWEgU3RhbmRhcmQgVGltZSkiLDQyOTQ5NjcyOTYsMiwiTW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfNykgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzE0OC4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiaHR0cHM6Ly9zZW50aW5lbC5vcGVuYWkuY29tL2JhY2tlbmQtYXBpL3NlbnRpbmVsL3Nkay5qcyIsbnVsbCwiZW4tR0IiLCJlbi1HQixlbi1VUyxlbiIsMywicGRmVmlld2VyRW5hYmxlZOKIknRydWUiLCJfcmVhY3RMaXN0ZW5pbmdvYWpieGVyYWJrIiwib25iZWZvcmV1bmxvYWQiLDI2MDY
```

**Response:**
```json
{
  "persona": "chatgpt-noauth",
  "token": "gAAAAABqG1FQrvAAvZqdStW-GxZ0xVcT9kB48PBLCvAWYXZH9ok6ASvHQ7nqIC2aZ_HqeCP37JaHVDc5KtR_7GXbXKQBJzr8oYA4mmBxsubffnQanRD_L6jHIH60ZuqYDs3N7fOqUhvT1ayQ4-k9B0p8AstMOuaYSVWz8SrY2iRhTRzpboHfG0M0qLNUIG0RyFLBPxVRsXOq9GA6tYCe9o7oaSReje3817XV1Pk7O1Dgb677wCM9DlFgOfTHyntqom8LCP8GTTebhPulQ855BwguuysdXeYnKkWDjTx6NnyeVZsIOi-zx3bF9M6iAQw_7lNhP1iSHyOM7NGHA58v8rdN65hyvKdh5_J_pZRth24ukIWqlFYuZSxsfxjUTaHDXz2cjdanb5jtC0Miy5m8L2fVKM8nT9a6Tnp07BJCIoFoVzcWhQAggo7mDm1oRiK6F4oqiqU
```

---

### GET /backend-api/user_granular_consent

**Method:** GET

**Response:**
```json
{
  "is_consent_required": true,
  "granular_consent": null
}
```

---

### GET /backend-api/accounts/optimized/check

**Method:** GET

**Response:**
```json
{
  "account": {
    "name": null,
    "profile_picture_url": null,
    "deactivated": false,
    "account_compute_residency": "no_constraint",
    "account_compute_residency_display_name": "No Constraint",
    "account_compute_residency_description": "No inference residency constraints",
    "workspace_type": null,
    "ekm_config": null,
    "is_fedramp_compliant_workspace": false
  },
  "account_user": {
    "role": "account-owner"
  },
  "features": [
    "aura_available",
    "bizmo_setting
```

---

### GET /backend-api/me

**Method:** GET

**Response:**
```json
{
  "object": "user",
  "id": "user-ZEaMEt54xKS3AV7VL4B39lDo",
  "email": "amrevrp@gmail.com",
  "name": "Supertramp Arpit",
  "picture": "https://cdn.auth0.com/avatars/va.png",
  "created": 1674465490,
  "phone_number": "+919580368316",
  "mfa_flag_enabled": true,
  "has_payg_project_spend_limit": true,
  "amr": [
    "pwd",
    "otp",
    "mfa",
    "urn:openai:amr:otp_totp"
  ],
  "claimed_domain_org_id": null,
  "groups": [],
  "email_domain_type": "social",
  "ads_segment_id": 7971,
  "orgs
```

---

### GET /backend-api/accounts/check/v4-2023-04-27

**Method:** GET

**Response:**
```json
{
  "accounts": {
    "509ab756-3207-4f5b-99bc-57794f71f6f5": {
      "account": {
        "account_user_role": "account-owner",
        "account_user_id": "user-ZEaMEt54xKS3AV7VL4B39lDo__509ab756-3207-4f5b-99bc-57794f71f6f5",
        "account_owner_id": "user-ZEaMEt54xKS3AV7VL4B39lDo",
        "account_residency_region": "no_constraint",
        "account_compute_residency": "no_constraint",
        "account_compute_residency_display_name": "No Constraint",
        "account_compute_residency_des
```

---

### GET /backend-api/user_system_messages

**Method:** GET

**Response:**
```json
{
  "object": "user_system_message_detail",
  "enabled": true,
  "about_user_message": "",
  "about_model_message": "",
  "name_user_message": "",
  "role_user_message": "",
  "traits_model_message": "",
  "personality_type_selection": "",
  "other_user_message": "",
  "disabled_tools": [],
  "traits_enabled": true,
  "personality_traits": {}
}
```

---

### GET /backend-api/settings/user

**Method:** GET

**Response:**
```json
{
  "beta_settings": {},
  "announcements": {
    "oai/apps/hasDismissedAG8PqS2q": "2024-05-18T09:13:45.176548",
    "oai/apps/hasDismissedCanvasContextualOnboarding": "2025-04-24T10:41:27.349113+00:00",
    "oai/apps/hasSeenAdvancedVoice/2024-09-24": "2024-10-26T12:42:25.676128+00:00",
    "oai/apps/hasSeenAdvancedVoiceOnMobile/2024-09-26": "2024-10-03T07:09:44.789256+00:00",
    "oai/apps/hasSeenAdvancedVoiceRealWebNuxTooltip": "2024-12-04T05:33:22.484052+00:00",
    "oai/apps/hasSeenAdvancedV
```

---

### POST /backend-api/sentinel/chat-requirements/prepare

**Method:** POST

**Response:**
```json
{
  "persona": "chatgpt-freeaccount",
  "prepare_token": "gAAAAABqG1HxJQPTfjQgSbRNatKynyDNwELPbBESQoHBYSP29hHli1_-JAuKXDWk-ET4NmrBzZ2iQYKEQcOKpLWitcpkpymFG1WC9mXm3xAKathpxfM4qDkIPTf4XZaN5ipqvQDzd96dFIB4yv8l1bJpfzwMJ5IsEv9NFQxh5MgGc_YxcBnkqqjEYjTWu9fcKpEMHQQ7hBaDQPpIhcwBF77yivDXSOBIOmWChc3zI2zsXN08orpZwpS1CujBzPGvBHnOOwNJl_5Me6_9D4kmBct7RscCRcP2KobIsa0aPdJMkWZbN1kKPUY0y9uWihBu2UjDpkILgrHXlSpOrj6Wbx8_cd2y_sc4uJfBIiGHt1BXl4lhRQTDrAyxmKEBB9x5SSdpZ3i0Lp-6DGnlDSGzk0qgorhetputSsvdjViokBFG_pV75j6kFFS7JU
```

---

### GET /backend-api/system_hints

**Method:** GET

**Response:**
```json
{
  "system_hints": [
    {
      "system_hint": "picture_v2",
      "name": "Create image",
      "description": "Visualize anything",
      "action_label": "Create image",
      "short_label": "Image",
      "logo": "<svg fill=\"none\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"m18.4384 2.51341c.893-.46272 1.9494-.25416 2.6259.42237.6765.67652.8851 1.73289.4224 2.62596-.8581 1.65615-1.8756 3.10686-3.1 4.41109 1.231 1.53077 2.1561 3.11657 2.5
```

---

### POST /backend-api/aip/connectors/list_accessible

**Method:** POST

**Response:**
```json
{
  "connectors": [
    {
      "id": "connector_251970f16cb647d4b76fc445753f9276",
      "canonical_connector_id": null,
      "template_id": null,
      "created_at": null,
      "updated_at": null,
      "connector_type": "SERVICE",
      "name": "Aha!",
      "description": "Connect to sync Aha! product roadmaps and features for use in ChatGPT.",
      "model_description": null,
      "service": "aha",
      "base_url": "https://{subdomain}.aha.io/api/v1",
      "supported_auth": [
        {
```

---

### POST /backend-api/aip/connectors/links/list_accessible

**Method:** POST

**Response:**
```json
{
  "links": [
    {
      "id": "implicit_link::connector_openai_deep_research",
      "created_at": "1970-01-01T00:00:00Z",
      "connector_id": "connector_openai_deep_research",
      "name": "Deep Research App",
      "actions": [
        "export",
        "get_inline_images",
        "get_state",
        "pause",
        "skip_sleep",
        "start",
        "steer",
        "stop",
        "subscribe"
      ],
      "auth_type": "NONE",
      "requested_scopes": null,
      "scopes": [],
```

---

### GET /backend-api/models

**Method:** GET

**Response:**
```json
{
  "title": "ChatGPT",
  "secondary_title": "",
  "models": [
    {
      "slug": "gpt-5-3",
      "max_tokens": 34834,
      "title": "GPT-5.3",
      "description": "Our latest and most advanced model",
      "tags": [
        "history_off_approved"
      ],
      "capabilities": {},
      "product_features": {
        "attachments": {
          "type": "retrieval",
          "accepted_mime_types": [
            "text/x-erlang",
            "application/pdf",
            "application/rtf",
  
```

---

### POST /backend-api/user_granular_consent

**Method:** POST

**Response:**
```json
{
  "is_success": true,
  "granular_consent": {
    "analytics": true,
    "marketing": true,
    "personalization": true
  }
}
```

---

### POST /backend-api/sentinel/chat-requirements/finalize

**Method:** POST

**Response:**
```json
{
  "persona": "chatgpt-freeaccount",
  "token": "gAAAAABqG1HxOCvtWQ7jJHHR-pFmTEisiY8BDRgtA49-6xwrwXHLfg76BPXsNfKneYDmgDH4JgjeQaKNXiYuz28cG4avpXLF_n5VCZ2EFvroTUkdW0Jo-hTNn5SA3-Q2jrblLSFkoNtjQ-0pQWimA1PGVEp73FXpd2-CepYnP46UCrQmM3UAyoQwqtaEDPNBWurEHGt7KzO1D9LFuEAlYGE9LzoCq5lQLW1MJvynhyKIjaJlHpYW5sQHiszJD3gXPGxEaD-UTeyAH2fdYSYlMHtV5XLjYQakCtjdkQlv6k8LLTV763Um_SrnY2e7Eq4d5IpbZA74YKfHJ_SYwRdwQaNDTcgfTyc522hkVE2RzdqfwgTjG3wW4El7f2hyWGmz5LWqjkSMPjGhwGdCTc6R2OVT7_aTFG9UNwJgJ3kYKsmgrxEjb2vBNt6L_KyBpT70Fr
```

---

### GET /backend-api/pins

**Method:** GET

**Response:**
```json
[]
```

---

### GET /backend-api/calpico/chatgpt/rooms/summary

**Method:** GET

**Response:**
```json
{
  "items": [],
  "cursor": null,
  "has_connection_requests": null
}
```

---

### POST /backend-api/conversation/init

**Method:** POST

**Response:**
```json
{
  "type": "conversation_detail_metadata",
  "banner_info": null,
  "blocked_features": [],
  "model_limits": [],
  "limits_progress": [
    {
      "feature_name": "deep_research",
      "remaining": 5,
      "reset_after": "2026-06-29T21:09:05.286765+00:00"
    },
    {
      "feature_name": "file_upload",
      "remaining": 7,
      "reset_after": "2026-05-31T21:09:05.286777+00:00"
    },
    {
      "feature_name": "paste_text_to_file",
      "remaining": 3,
      "reset_after": "2026-05-31
```

---

### GET /backend-api/conversations

**Method:** GET

**Response:**
```json
{
  "items": [
    {
      "id": "6a1b09c5-b268-8320-b343-3f0b28f30e3f",
      "title": "New chat",
      "create_time": "2026-05-30T16:01:11.201054Z",
      "update_time": "2026-05-30T16:01:44.202800Z",
      "pinned_time": null,
      "mapping": null,
      "current_node": null,
      "conversation_template_id": null,
      "gizmo_id": null,
      "is_archived": false,
      "is_starred": null,
      "is_temporary_chat": false,
      "is_do_not_remember": false,
      "memory_scope": "global_e
```

---

### GET /backend-api/checkout_pricing_config/countries

**Method:** GET

**Response:**
```json
{
  "countries": [
    "NR",
    "XK",
    "TZ",
    "OM",
    "TV",
    "FK",
    "CG",
    "AO",
    "JE",
    "SO",
    "UG",
    "LS",
    "NP",
    "MN",
    "PW",
    "AM",
    "MG",
    "MP",
    "RW",
    "BR",
    "LR",
    "DZ",
    "LU",
    "BN",
    "KR",
    "TH",
    "HU",
    "TG",
    "AR",
    "GT",
    "NZ",
    "LI",
    "MM",
    "BM",
    "MH",
    "ST",
    "IQ",
    "TO",
    "IN",
    "AX",
    "ER",
    "IE",
    "SM",
    "GR",
    "FI",
    "PF",
    "SB",
    "SV",
 
```

---

### GET /backend-api/user_segments/codex_surface_usage

**Method:** GET

**Response:**
```json
{
  "used_cli_30d": false,
  "used_vscode_30d": false,
  "used_desktop_app_30d": false
}
```

---

### GET /backend-api/user_segments

**Method:** GET

**Response:**
```json
{
  "segments": {
    "k2m9v4x7p1q8": false,
    "r5n8c1t6w3k4": false,
    "h7q2m5x9v1p4": true,
    "t6c4q9v2m8p1": true,
    "b4t9k2w7n5c1": false
  }
}
```

---

### GET /backend-api/gizmos/snorlax/sidebar

**Method:** GET

**Response:**
```json
{
  "items": [
    {
      "gizmo": {
        "gizmo": {
          "id": "g-p-67b38d7ee1148191857b04ef2344a4b6",
          "organization_id": "org-bwqlKmsKC6ArWqhbqdj2waoJ",
          "short_url": "g-p-67b38d7ee1148191857b04ef2344a4b6-react-native",
          "author": {
            "user_id": "user-ZEaMEt54xKS3AV7VL4B39lDo",
            "user_email": "amrevrp@gmail.com",
            "display_name": "Supertramp Arpit",
            "link_to": null,
            "is_verified": false,
            "s
```

---

### GET /backend-api/client/strings

**Method:** GET

**Response:**
```json
{
  "caterpillar_status_message_texts": {
    "completed_message": "Research completed in",
    "cancelled_message": "Research task cancelled",
    "failure_message": "Research task failed",
    "failure_banner_content_message": "There was a problem completing the research",
    "waiting_in_queue_message": "Your deep research request is queued up. You'll get a notification when research is complete.",
    "starting_message": "Starting research",
    "none_selected_dr_message": "Choose at least o
```

---

### GET /backend-api/apps/sources_dropdown

**Method:** GET

**Response:**
```json
{
  "entities": {
    "access_sources": {},
    "sync_sources": {}
  },
  "modes": {
    "drLegacy": {
      "capabilities": {
        "web_search": "implicit",
        "cloud_browser": "unavailable",
        "sync_connectors": "unavailable",
        "connect_more": "visible"
      },
      "access_source_refs": [],
      "sync_source_refs": []
    },
    "draDefault": {
      "capabilities": {
        "web_search": "implicit",
        "cloud_browser": "unavailable",
        "sync_connectors": "
```

---

### GET /backend-api/prompt_library/

**Method:** GET

**Response:**
```json
{
  "items": [
    {
      "id": "use-case-create-image",
      "title": "Create an image",
      "description": "",
      "prompt": "",
      "oneliner": "",
      "category": "dalle",
      "destination": "simple-use-case-hub",
      "requires_dalle": true,
      "icon": {
        "icon_name": "image-square",
        "use_accent_color": false
      },
      "icon_url": {
        "64_1x": "https://persistent.oaistatic.com/chatgpt/icons/use-case-icons//gray/image-square@3x.png",
        "64_2x":
```

---

### GET /backend-api/images/bootstrap

**Method:** GET

**Response:**
```json
{
  "images_count": 17,
  "archived_images_count": 0,
  "thumbnail_url": "https://chatgpt.com/backend-api/estuary/content?id=9893211a2eed213%23file_00000000b5ec72079917e94c26edc960%23icon&cp=pri&ma=90000&ts=20603&p=igh&cid=1&sig=8525521f1a318eb121331232b99d1788d69c6e8399ef7daad9cfeb6a5e48e426&v=0"
}
```

---

### GET /backend-api/beacons/home

**Method:** GET

**Response:**
```json
{
  "beacon_ui_response": null
}
```

---

### GET /backend-api/amphora/notifications

**Method:** GET

**Response:**
```json
{
  "items": [],
  "cursor": null
}
```

---

### POST /backend-api/accounts/backfill_workspace_owner_domains

**Method:** POST

**Response:**
```json
{
  "success": true
}
```

---

### GET /backend-api/user_surveys/active

**Method:** GET

**Response:**
```json
{
  "survey": null
}
```

---

### GET /backend-api/tasks

**Method:** GET

**Response:**
```json
{
  "tasks": [
    {
      "user_id": "user-ZEaMEt54xKS3AV7VL4B39lDo",
      "task_id": "imagegen_6a1b09cb184c81919cadb1603f239845",
      "title": "Curious kitten on a cosy cushion",
      "prompt": "",
      "created_at": "2026-05-30 16:01:15.095151+00:00",
      "updated_at": "2026-05-30 16:01:43.942614+00:00",
      "conversation_id": "6a1b09c5-b268-8320-b343-3f0b28f30e3f",
      "status": "completed",
      "messages": [],
      "final_message": null,
      "original_conversation_id": "6a1b
```

---

### GET /backend-api/celsius/ws/user

**Method:** GET

**Response:**
```json
{
  "websocket_url": "wss://ws.chatgpt.com/p20/ws/user/user-ZEaMEt54xKS3AV7VL4B39lDo?verify=1780175347-hjfH1Llg5A8ZJWTGbY70aeqf6Y%252BQv9kDkj3rR8QiFzE%253D"
}
```

---

### GET /backend-api/memories

**Method:** GET

**Response:**
```json
{
  "memories": [],
  "memory_max_tokens": 2000,
  "memory_num_tokens": 1336
}
```

---

### GET /backend-api/checkout_pricing_config/configs/IN

**Method:** GET

**Response:**
```json
{
  "country_code": "IN",
  "currency_config": {
    "free": {
      "month": {
        "tax": "inclusive",
        "amount": 0
      }
    },
    "go": {
      "month": {
        "amount": 399,
        "tax": "inclusive"
      }
    },
    "plus": {
      "month": {
        "amount": 1999,
        "tax": "inclusive",
        "psp_override": {
          "amount": 1694.07,
          "tax": "exclusive"
        }
      }
    },
    "pro": {
      "month": {
        "amount": 19900,
        "tax": "
```

---

### GET /backend-api/gizmos/bootstrap

**Method:** GET

**Response:**
```json
{
  "gizmos": [
    {
      "resource": {
        "gizmo": {
          "id": "g-2Eo3NxuS7",
          "organization_id": "org-S6eCwFL4YpT1JA00esUW9Oze",
          "short_url": "g-2Eo3NxuS7-designergpt",
          "author": {
            "user_id": "user-5p8mKZIxdEy3dO92djum4fxG",
            "user_email": null,
            "display_name": "Pietro Schirano",
            "link_to": null,
            "is_verified": true,
            "selected_display": "name",
            "will_receive_support_emai
```

---

### GET /backend-api/gizmos/g-2Eo3NxuS7

**Method:** GET

**Response:**
```json
{
  "gizmo": {
    "id": "g-2Eo3NxuS7",
    "organization_id": "org-S6eCwFL4YpT1JA00esUW9Oze",
    "short_url": "g-2Eo3NxuS7-designergpt",
    "author": {
      "user_id": "user-5p8mKZIxdEy3dO92djum4fxG",
      "user_email": null,
      "display_name": "Pietro Schirano",
      "link_to": null,
      "is_verified": true,
      "selected_display": "name",
      "will_receive_support_emails": true,
      "display_socials": [
        {
          "id": "twitterverify-43d2-b12a-bbe33d600487",
        
```

---

### GET /backend-api/settings/voices

**Method:** GET

**Response:**
```json
{
  "selected": "juniper",
  "voices": [
    {
      "voice": "orbit",
      "name": "Spruce",
      "gain_db": null,
      "preview_url": "https://persistent.oaistatic.com/voice/previews/orbit.en.be588b89.m4a",
      "description": "Calm and affirming",
      "bloop_color": "808080"
    },
    {
      "voice": "breeze",
      "name": "Breeze",
      "gain_db": null,
      "preview_url": "https://persistent.oaistatic.com/voice/previews/breeze.en.5fc1dadf.m4a",
      "description": "Animated and 
```

---

### POST /backend-api/files/library

**Method:** POST

**Response:**
```json
{
  "items": [
    {
      "id": "libfile_9a862048633081919e5acc776fa64310",
      "file_id": "file_00000000ba60720b8dae66298e5bdfa8",
      "file_name": "748b1681-9ea9-4f14-9579-f11199d2e751.png",
      "directory_id": "libdir_5f4306b459c48191b353d8c108ee891f",
      "current_version_number": null,
      "content_backing_kind": "sediment",
      "mime_type": "image/png",
      "file_extension": "png",
      "file_size_bytes": 598683,
      "library_file_category": "image",
      "state": "ready
```

---

### POST /backend-api/sentinel/heartbeat

**Method:** POST

**Response:**
```json
{
  "status": "OK"
}
```

---

### POST /backend-api/f/conversation/prepare

**Method:** POST

**Response:**
```json
{
  "status": "ok",
  "conduit_token": "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb25kdWl0X3V1aWQiOiIzNDcwYzdhMDFlYTg0YTY1OWZmYjViN2RmNzdkYjViYSIsImNvbmR1aXRfbG9jYXRpb24iOiIxMC4xMzEuMTczLjExNjo4MzA3IiwiY2x1c3RlciI6InVuaWZpZWQtMTQ0IiwiaWF0IjoxNzgwMTc1NDY0LCJleHAiOjE3ODAxNzU1MjQsInR1cm5fdG9waWNfaWQiOm51bGx9.I5LCjvh7t4mfMiTPuxG8zFrSTQ9WtmxqOI0rL4MGHueoBQWhS4fhhhr2yy8uwvHpQPr3aPeYDJvMPQsG5VMCOA"
}
```

---

### POST /backend-api/conversation/experimental/generate_autocompletions

**Method:** POST

**Response:**
```json
{
  "completions": []
}
```

---

### GET /backend-api/sentinel/sdk.js

**Method:** GET

---

### POST /backend-api/f/conversation

**Method:** POST

**Request Body:**
```json
{
  "action": "next",
  "messages": [
    {
      "id": "3ebaeca8-3b21-475d-80bc-441050b39ae1",
      "author": {
        "role": "user"
      },
      "create_time": 1780175465.304,
      "content": {
        "content_type": "text",
        "parts": [
          "hii"
        ]
      },
      "metadata": {
        "selected_github_repos": [],
        "selected_all_github_repos": false,
        "serialization_metadata": {
          "custom_symbol_offsets": []
        }
      }
    }
  ],
  "paren
```

---

### GET /backend-api/settings/is_adult

**Method:** GET

**Response:**
```json
{
  "is_adult": true,
  "has_verified_age_or_dob": false,
  "age_is_known": true,
  "is_u18_model_policy_enabled": false,
  "show_age_verification_setting": false,
  "age_status": "over_18",
  "citron_eligibility_status": "region_block"
}
```

---

### POST /backend-api/sentinel/ping

**Method:** POST

**Response:**
```json
{
  "status": "OK"
}
```

---

### GET /backend-api/sentinel/frame.html

**Method:** GET

---

### GET /backend-api/conversation/6a1b5268-05d8-83a9-9b15-cb03074c4572/stream_status

**Method:** GET

**Response:**
```json
{
  "status": "IS_STREAMING"
}
```

---

### POST /backend-api/sentinel/req

**Method:** POST

**Request Body:**
```json
{
  "p": "gAAAAACWzIzNDAsIlN1biBNYXkgMzEgMjAyNiAwMjo0MTowNSBHTVQrMDUzMCAoSW5kaWEgU3RhbmRhcmQgVGltZSkiLDQyOTQ5NjcyOTYsNjgsIk1vemlsbGEvNS4wIChNYWNpbnRvc2g7IEludGVsIE1hYyBPUyBYIDEwXzE1XzcpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xNDguMC4wLjAgU2FmYXJpLzUzNy4zNiIsImh0dHBzOi8vY2hhdGdwdC5jb20vYmFja2VuZC1hcGkvc2VudGluZWwvc2RrLmpzIiwicHJvZC0zNTU4OTI2NzY0NDMyMDhkMGViODdhZWFlYjE3ZDNlZjMzMjdmMjNmIiwiZW4tR0IiLCJlbi1HQixlbi1VUyxlbiIsNTU4LCJnZW9sb2NhdGlvbuKIkltvYmplY3QgR2VvbG9jYXRpb25dIiw
```

**Response:**
```json
{
  "persona": "chatgpt-noauth",
  "token": "gAAAAABqG1Jq178VTHvAIzklZJwdOrxTdpkpPPB2ahKJ5mlucruTCwSz4s8V-6LBSZOEU4QTcMdv-sBIj_i_-D1e7ZCcA6UkJze6tIp0-Wd6kuy-sA06EJB6R7iwtDmuvq51L7C2uoegOYuXcZJyF56H0hn1L9-SshXIPB7ZFCxPWF5m3vrsPu-D55fwOyItC4VGKHSBXI97iEWXGzzGTlgoIHUj_djmQMlibWiap-xqIpyHFIuA64dSBrUNbjbcjsNWzZXIXXCBUT-8MXXkaMjJ2tuSaPBsXI-mNz0ETkkEkvYMGS23C18rSVH8JGnRX_-4ZSBGbCjZCeoabVgeq5hjb90T2023D9VjUVq5MQzECO4VzjpU830ZjR-Bi7JleqoZBBPwUY6JB6G2E4RZRP8v8uTvBUJT4CyYPjN19R2xlv8kRkcEeZU9GU2Up7NfDvwNIVe
```

---

### GET /backend-api/conversation/6a1b5268-05d8-83a9-9b15-cb03074c4572/textdocs

**Method:** GET

**Response:**
```json
[]
```

---

### POST /backend-api/lat/r

**Method:** POST

**Response:**
```json
{
  "status": "success"
}
```

---

