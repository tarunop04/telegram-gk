# ChatGPT Connector OAuth Flow - Complete Documentation

## Overview

This document describes the complete OAuth flow for connecting third-party services (Canva, GitHub, Slack, etc.) to ChatGPT. The flow has been reverse-engineered from the ChatGPT mobile app and web frontend.

## The Problem

ChatGPT connectors typically require OAuth authorization to access third-party services. The standard flow in the ChatGPT app uses:

1. A popup window that opens the third-party OAuth provider
2. The user completes authorization
3. The popup redirects to a ChatGPT callback URL
4. The popup uses `postMessage` to communicate the result back to the parent window
5. ChatGPT verifies the callback and creates the connector link

This flow is tightly coupled to the ChatGPT web/app UI and doesn't work for API-only access.

## Our Solution

We've reverse-engineered the flow to work with a local callback server:

1. **Start OAuth**: Call the ChatGPT API to initiate OAuth, providing our local callback URL
2. **User Authorization**: User opens the redirect URL in any browser
3. **Capture Callback**: Our local HTTP server captures the OAuth callback with the authorization code
4. **Verify**: Call the ChatGPT verification API with the full callback URL (including code and state)
5. **Done**: The connector is now linked and works across all devices

## API Endpoints

### Start OAuth Flow

```
POST /backend-api/aip/connectors/links/oauth
```

**Request:**
```json
{
    "connector_id": "connector_68df33b1a2d081918778431a9cfca8ba",
    "name": "Canva",
    "callback_url": "http://localhost:9876/oauth/callback"
}
```

**Response:**
```json
{
    "oauth_state_id": "oauth_s_6a1eecf2599c8191be43c74ccc0e0b96",
    "redirect_url": "https://openai.canva.com/authorize?response_type=code&client_id=...",
    "email_challenge_sent": null
}
```

### Verify OAuth Callback

```
POST /backend-api/aip/connectors/links/oauth/verification
```

**Request:**
```json
{
    "connector_id": "connector_68df33b1a2d081918778431a9cfca8ba",
    "callback_url": "http://localhost:9876/oauth/callback?code=AUTH_CODE&state=oauth_s_xxx"
}
```

**Response:**
```json
{
    "link_id": "link_xxx",
    "success": true
}
```

## Key Discoveries

### 1. Callback URL is Flexible

The OAuth API accepts any valid HTTP URL as the callback, not just the mobile deep link. This allows us to use `http://localhost:PORT` for local OAuth flows.

### 2. State Parameter Encodes OAuth State ID

The `state` parameter in the OAuth flow contains the `oauth_state_id` returned from the start endpoint. This is used to correlate the callback with the original request.

### 3. Verification Uses Full Callback URL

The verification endpoint expects the complete callback URL including all query parameters (`code`, `state`, etc.). Don't strip the parameters.

### 4. Connector Links Are Account-Wide

Once a connector is linked, it's associated with your OpenAI account and works across all devices and sessions using the same account.

### 5. No Session Context Required

Unlike the web popup flow, our API flow doesn't require any session context or cookies. Just the access token.

## Connector ID Formats

Connectors use two ID formats:

1. **Legacy format**: `connector_HASH` (e.g., `connector_68df33b1a2d081918778431a9cfca8ba`)
2. **New ASDK format**: `asdk_app_HASH` (e.g., `asdk_app_69c18c28f1188191bf5b8445c4ab0a2e`)

Both formats work with the OAuth endpoints.

## Known Connector IDs

| Service | Connector ID |
|---------|-------------|
| Canva | `connector_68df33b1a2d081918778431a9cfca8ba` |
| GitHub | `connector_76869538009648d5b282a4bb21c3d157` |
| Notion | `asdk_app_69c18c28f1188191bf5b8445c4ab0a2e` |
| Slack | `asdk_app_69a1d78e929881919bba0dbda1f6436d` |
| Asana | `asdk_app_69616780bd208191b4fb44ba44f72b61` |
| Linear | `asdk_app_69a089a326dc8191b32a3f2553f5be2c` |
| HubSpot | `asdk_app_697acb8e53d88191bf7a79e62012ae14` |
| Dropbox | `asdk_app_69b31dc2110c8191b8b47dc98fe5a052` |
| Box | `asdk_app_695bfc98071c8191bac7bc479aa27de7` |
| SharePoint | `connector_1e4f6a44acf14e3ca1d96672f8c945bc` |

## Usage Examples

### Python - Complete Flow

```python
from chatgpt_oauth_flow import run_oauth_flow

# Run OAuth flow (starts local server, opens browser, waits for callback)
result = run_oauth_flow(
    access_token="YOUR_ACCESS_TOKEN",
    connector_name="canva",
    callback_port=9876,
    auto_open_browser=True
)

if result["success"]:
    print(f"Connected! Link ID: {result['link_id']}")
```

### Python - Manual Flow

```python
from chatgpt_oauth_flow import ChatGPTOAuthClient

client = ChatGPTOAuthClient(access_token="YOUR_ACCESS_TOKEN")

# 1. Start OAuth
oauth_result = client.start_oauth(
    connector_id="connector_68df33b1a2d081918778431a9cfca8ba",
    callback_url="http://localhost:9876/oauth/callback",
    name="Canva"
)

print(f"Open this URL: {oauth_result['redirect_url']}")

# 2. After user completes OAuth, browser redirects to:
#    http://localhost:9876/oauth/callback?code=xxx&state=xxx

# 3. Verify with full callback URL
verify_result = client.verify_oauth(
    connector_id="connector_68df33b1a2d081918778431a9cfca8ba",
    callback_url_with_params="http://localhost:9876/oauth/callback?code=xxx&state=xxx"
)

print(f"Linked! Link ID: {verify_result['link_id']}")
```

### CLI

```bash
# Connect Canva
python chatgpt_oauth_flow.py --connector canva --token YOUR_TOKEN

# List linked connectors
python chatgpt_oauth_flow.py --list --token YOUR_TOKEN

# List available connectors
python chatgpt_oauth_flow.py --available --token YOUR_TOKEN
```

### Proxy API

```bash
# Start OAuth flow
curl -X POST http://localhost:8080/v1/connectors/oauth/start \
  -H "Content-Type: application/json" \
  -d '{"connector_id": "connector_68df33b1a2d081918778431a9cfca8ba"}'

# After completing OAuth in browser, verify:
curl -X POST http://localhost:8080/v1/connectors/oauth/verify \
  -H "Content-Type: application/json" \
  -d '{
    "connector_id": "connector_68df33b1a2d081918778431a9cfca8ba",
    "callback_url": "http://localhost:9876/oauth/callback?code=xxx&state=xxx"
  }'
```

## Using Connectors in Conversations

Once linked, add connectors to conversations using `system_hints`:

```json
{
    "action": "next",
    "messages": [...],
    "model": "auto",
    "system_hints": ["connector:connector_68df33b1a2d081918778431a9cfca8ba"]
}
```

Or use the proxy API with the `tools` parameter:

```bash
curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4o",
    "messages": [{"role": "user", "content": "Create a poster for my event"}],
    "tools": ["connector:connector_68df33b1a2d081918778431a9cfca8ba"]
  }'
```

## Implementation Files

- `chatgpt_oauth_flow.py` - Standalone OAuth flow client with local callback server
- `chatgpt_connectors.py` - Connector API client library
- `chatgpt_proxy_api.py` - Proxy server with connector endpoints
- `test_canva_oauth.py` - Example script to test Canva OAuth

## Security Considerations

1. The local callback server only binds to localhost
2. The OAuth state parameter prevents CSRF attacks
3. Tokens should be stored securely (not in code)
4. The callback server auto-stops after receiving a callback

## Troubleshooting

### "Connector not found"
- Check the connector ID is correct
- Some connectors have both legacy and new IDs

### "Internal Server Error" when opening redirect URL
- The redirect URL is valid only once
- Start a new OAuth flow

### Callback never received
- Check firewall allows localhost:PORT
- Ensure browser doesn't block popups
- Try a different port

### "Email challenge sent"
- Some connectors require email verification
- Check your email for a verification code
- The flow will need to be modified to handle this
