# ChatGPT Desktop API

**Send messages to ChatGPT from the command line / Python scripts.**

This bypasses all Cloudflare/Turnstile/Sentinel protections by typing directly into the browser.

## Quick Start

### 1. Start the server

```bash
node chatgpt_type.js
```

A browser window opens. Log in to ChatGPT if needed (only once - session persists).

### 2. Use from Python

```python
from chatgpt import ChatGPT

gpt = ChatGPT()
print(gpt.chat("Hello!"))

# Or shorthand
print(gpt("What is 2+2?"))
```

### 3. Or use curl

```bash
curl -X POST http://localhost:8767/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello!"}'
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/status` | Server status |
| POST | `/chat` | Send message |
| POST | `/new` | Start new chat |
| GET | `/screenshot` | Debug screenshot |

### POST /chat

```json
{"message": "Your message here"}
```

Response:
```json
{"response": "ChatGPT's response"}
```

## Files

| File | Description |
|------|-------------|
| `chatgpt_type.js` | Browser server (run this first) |
| `chatgpt.py` | Python client library |

## How It Works

1. **Browser Server** (`chatgpt_type.js`)
   - Opens Chrome with persistent session
   - Exposes HTTP API on localhost:8767
   - Types messages directly into ChatGPT UI
   - Waits for and extracts responses

2. **Python Client** (`chatgpt.py`)
   - Connects to the browser server
   - Simple `chat()` method
   - Handles errors and timeouts

## Why This Approach?

ChatGPT uses multiple protection layers:
- ❌ Cloudflare Turnstile (CAPTCHA)
- ❌ Sentinel Proof-of-Work
- ❌ Session Observer (fingerprinting)
- ❌ Request binding to browser session

By typing into the actual UI, we bypass all of these - the browser handles everything naturally.

## Interactive Mode

```bash
python chatgpt.py
```

```
==================================================
   ChatGPT Desktop Client
==================================================

Commands:
  /new    - Start new chat
  /quit   - Exit

✅ Ready! Type your message.

You: Hello!
ChatGPT: Hello! How can I help you today?

You: What's the weather like?
ChatGPT: I don't have access to real-time weather data...
```

## Requirements

- Node.js
- Python 3
- Playwright: `npm install playwright`
- Requests: `pip install requests`

## Session Persistence

The browser session is stored in `.chatgpt-session/`. Once you log in, it stays logged in across restarts.

To reset: delete the `.chatgpt-session` folder.

## Limitations

- One message at a time (sequential)
- Requires visible browser window
- Response time depends on ChatGPT's speed

## License

For educational and personal use only.
