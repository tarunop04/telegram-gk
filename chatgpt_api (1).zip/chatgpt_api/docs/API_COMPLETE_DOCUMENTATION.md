# ChatGPT Mobile API - Complete Documentation


## Base URLs
- **Main API**: `https://android.chat.openai.com`
- **Auth**: `https://auth.openai.com`
- **WebSocket**: `wss://ws.chatgpt.com`
- **AB Testing**: `https://ab.chatgpt.com`

## Required Headers
```
User-Agent: ChatGPT/1.2026.139 (Android 12; Surface Duo; build 2613921)
oai-device-id: <uuid>
oai-client-type: android
oai-package-name: com.openai.chatgpt
Authorization: Bearer <access_token>
Accept: application/json
Content-Type: application/json
```

## Required Cookies
```
oai-sc: <session_cookie>
_playintegrity: <play_integrity_token>
__cf_bm: <cloudflare_cookie>
_cfuvid: <cloudflare_visitor_id>
```

## Endpoints

### User
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /backend-api/me | Get user info |
| GET | /backend-api/settings/user | Get settings |
| GET | /backend-api/memories | Get memories |
| GET | /backend-api/accounts/check/v4-2023-04-27 | Account status |

### Models
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /backend-api/models | List models |
| GET | /backend-anon/models | List models (anon) |

### Conversations
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /backend-api/conversations | List conversations |
| GET | /backend-api/conversation/{id} | Get conversation |
| POST | /backend-api/f/conversation/prepare | Prepare chat |
| POST | /backend-api/conversation/init | Init conversation |

### Chat (WebSocket)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /backend-api/celsius/ws/user | Get WebSocket URL |
| WSS | ws.chatgpt.com/p19/ws/user/{user_id} | Real-time chat |

### GPTs
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /backend-api/gizmos/bootstrap | Get GPTs |
| GET | /backend-api/gizmos/snorlax/sidebar | Sidebar GPTs |
| GET | /backend-api/apps/directory/installed | Installed apps |

### Images
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /backend-api/images/init | Image init |
| GET | /backend-api/my/recent/image_gen | Recent images |

### Voices
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /backend-api/settings/voices | Available voices |

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /oauth/token | Get access token |
| POST | /api/first_party_authorize/next | Auth flow |
| GET | /api/accounts/authorize | Authorize |

## Usage

```python
from chatgpt_final_client import ChatGPTClient

# Create client
client = ChatGPTClient()

# Get user
me = client.get_me()
print(me["email"])

# Get models
models = client.get_models()

# Get conversations
convs = client.get_conversations()

# Chat via WebSocket
response = client.chat("Hello!")
```

## Token Refresh

Tokens expire after ~10 days. To refresh:
1. Run the capture script again
2. Log into the mobile app
3. Extract new tokens from captured_endpoints.json

## Files
- `chatgpt_final_client.py` - Main client
- `captured_endpoints.json` - Raw captured data
- `captured_traffic.jsonl` - Full request/response log
- `FULL_API_DOCUMENTATION.json` - Structured API docs
