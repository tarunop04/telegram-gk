# ChatGPT API — Consolidated Folder

All ChatGPT-specific API files and documentation, gathered in one place.
Files were **copied** here from the project root (originals left untouched).

## Folder layout

```
chatgpt_api/
├── INDEX.md          ← this file
├── docs/             ← documentation & endpoint specs
├── src/              ← API server + client implementation
└── capture/          ← traffic/endpoint discovery scripts
```

## docs/ — Documentation

| File | Description |
|------|-------------|
| [README.md](docs/README.md) | Quick-start guide for the ChatGPT Desktop API |
| [CHATGPT_API.md](docs/CHATGPT_API.md) | Main ChatGPT API reference |
| [API_COMPLETE_DOCUMENTATION.md](docs/API_COMPLETE_DOCUMENTATION.md) | Complete API documentation |
| [CONNECTORS_API.md](docs/CONNECTORS_API.md) | Connectors API reference |
| [OAUTH_FLOW.md](docs/OAUTH_FLOW.md) | OAuth authentication flow |
| [SECURITY_ANALYSIS.md](docs/SECURITY_ANALYSIS.md) | Security analysis notes |
| [API_ENDPOINTS_SUMMARY.json](docs/API_ENDPOINTS_SUMMARY.json) | Summary of discovered endpoints |
| [FULL_API_DOCUMENTATION.json](docs/FULL_API_DOCUMENTATION.json) | Full machine-readable endpoint dump |

## src/ — Implementation

| File | Description |
|------|-------------|
| [chatgpt_type.js](src/chatgpt_type.js) | Browser-typing server (recommended entry point — `node chatgpt_type.js`) |
| [chatgpt_server.js](src/chatgpt_server.js) | HTTP server implementation |
| [chatgpt_browser_api.js](src/chatgpt_browser_api.js) | Browser automation API client |

## capture/ — Endpoint discovery

| File | Description |
|------|-------------|
| [capture_endpoints.js](capture/capture_endpoints.js) | Capture ChatGPT network endpoints |
| [capture_full_auth.js](capture/capture_full_auth.js) | Capture full auth flow |
| [capture_real_chrome.js](capture/capture_real_chrome.js) | Capture via real Chrome instance |
| [capture_stealth.js](capture/capture_stealth.js) | Stealth-mode capture |
| [capture_tokens.js](capture/capture_tokens.js) | Token extraction |
| [capture_all_endpoints.sh](capture/capture_all_endpoints.sh) | Orchestration script for all captures |
| [captured_endpoints.json](capture/captured_endpoints.json) | Captured endpoint data |

---

### Not included (belong to other services)
Grok, Gemini, NotebookLM, Canva, and Reddit files remain in the project root,
as do large raw capture artifacts (`chatgpt.apk`, `captured_traffic.jsonl`,
`chatgpt_traffic.flow`, `captured_connector_flow.txt`).
