/**
 * ChatGPT Browser Server - Fixed Version
 * Uses browser's fetch for all API calls (bypasses Turnstile)
 */

const { chromium } = require('playwright');
const http = require('http');
const path = require('path');

const PORT = 8766;
let page = null;
let browser = null;
let isReady = false;

async function init() {
  console.log('🚀 Starting browser...');

  browser = await chromium.launchPersistentContext(
    path.join(__dirname, '.chatgpt-session'),
    {
      headless: false,
      executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      args: ['--disable-blink-features=AutomationControlled'],
      ignoreDefaultArgs: ['--enable-automation'],
      viewport: { width: 1280, height: 900 },
    }
  );

  page = browser.pages()[0] || await browser.newPage();

  await page.addInitScript(() => {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
  });

  console.log('🌐 Opening ChatGPT...');
  await page.goto('https://chatgpt.com/', { waitUntil: 'networkidle', timeout: 60000 });

  // Wait for logged-in state
  console.log('⏳ Waiting for login...');
  try {
    await page.waitForFunction(() => {
      // Check if we can access authenticated endpoint
      return document.querySelector('[data-testid="send-button"]') ||
             document.querySelector('button[aria-label*="Send"]') ||
             document.querySelector('#prompt-textarea') ||
             document.querySelector('textarea');
    }, { timeout: 120000 });

    isReady = true;
    console.log('✅ Ready!');
  } catch (e) {
    console.log('⚠️ Waiting for manual login...');
  }
}

// Execute fetch in browser context
async function browserFetch(url, options = {}) {
  return page.evaluate(async ({ url, options }) => {
    const resp = await fetch(url, {
      ...options,
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    });

    const contentType = resp.headers.get('content-type') || '';

    if (contentType.includes('text/event-stream')) {
      // Handle streaming response
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let result = '';
      let fullText = '';
      let conversationId = null;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        result += decoder.decode(value, { stream: true });
        const lines = result.split('\n');
        result = lines.pop(); // Keep incomplete line

        for (const line of lines) {
          if (line.startsWith('data: ') && line !== 'data: [DONE]') {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.message?.content?.parts?.[0]) {
                fullText = data.message.content.parts[0];
              }
              if (data.conversation_id) {
                conversationId = data.conversation_id;
              }
            } catch (e) {}
          }
        }
      }

      return { ok: true, streaming: true, text: fullText, conversation_id: conversationId };
    }

    const text = await resp.text();
    try {
      return { ok: resp.ok, status: resp.status, data: JSON.parse(text) };
    } catch {
      return { ok: resp.ok, status: resp.status, text };
    }
  }, { url, options });
}

// Send message via browser fetch
async function sendMessage(message, model = 'auto', conversationId = null) {
  const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });

  const payload = {
    action: 'next',
    messages: [{
      id: uuid(),
      author: { role: 'user' },
      content: { content_type: 'text', parts: [message] },
      metadata: { serialization_metadata: { custom_symbol_offsets: [] } }
    }],
    parent_message_id: uuid(),
    model: model,
    timezone_offset_min: -330,
    timezone: 'Asia/Calcutta',
    conversation_mode: { kind: 'primary_assistant' },
    client_prepare_state: 'success',
    supports_buffering: true,
  };

  if (conversationId) {
    payload.conversation_id = conversationId;
  }

  // Use the browser to make the request (has all cookies & tokens)
  const result = await page.evaluate(async (payload) => {
    // Generate UUID
    const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });

    try {
      // Step 1: Prepare chat requirements
      const prepResp = await fetch('/backend-api/sentinel/chat-requirements/prepare', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(null)
      });

      if (!prepResp.ok) {
        return { error: `Prepare failed: ${prepResp.status}` };
      }

      // Step 2: Get token from SentinelSDK
      let chatToken = null;
      let proofToken = null;

      if (window.SentinelSDK) {
        try {
          const tokenResult = await Promise.race([
            window.SentinelSDK.token(),
            new Promise((_, reject) => setTimeout(() => reject(new Error('Sentinel timeout')), 10000))
          ]);

          // Parse the token result - it's a JSON string
          if (typeof tokenResult === 'string') {
            try {
              const parsed = JSON.parse(atob(tokenResult.split('.')[1] || '{}'));
              chatToken = tokenResult;
            } catch {
              chatToken = tokenResult;
            }
          }
        } catch (e) {
          console.log('SentinelSDK error:', e.message);
        }
      }

      // Step 3: Send the message
      const resp = await fetch('/backend-api/conversation', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'text/event-stream',
          ...(chatToken && { 'openai-sentinel-chat-requirements-token': chatToken })
        },
        body: JSON.stringify(payload)
      });

      if (!resp.ok) {
        const errText = await resp.text();
        return { error: `HTTP ${resp.status}: ${errText.substring(0, 300)}` };
      }

      // Read streaming response
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let fullText = '';
      let conversationId = null;
      let messageId = null;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop();

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') continue;

            try {
              const parsed = JSON.parse(data);
              if (parsed.message?.content?.parts?.[0]) {
                fullText = parsed.message.content.parts[0];
              }
              if (parsed.conversation_id) {
                conversationId = parsed.conversation_id;
              }
              if (parsed.message?.id) {
                messageId = parsed.message.id;
              }
            } catch (e) {}
          }
        }
      }

      return {
        response: fullText,
        conversation_id: conversationId,
        message_id: messageId
      };

    } catch (e) {
      return { error: e.message };
    }
  }, payload);

  return result;
}

// HTTP Server
const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://localhost:${PORT}`);

  try {
    // GET /status
    if (req.method === 'GET' && url.pathname === '/status') {
      const pageUrl = page ? await page.url() : null;
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ready: isReady, url: pageUrl }));
      return;
    }

    // GET /me
    if (req.method === 'GET' && url.pathname === '/me') {
      const result = await browserFetch('/backend-api/me');
      res.writeHead(result.ok ? 200 : 500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result.data || { error: result.text }));
      return;
    }

    // GET /models
    if (req.method === 'GET' && url.pathname === '/models') {
      const result = await browserFetch('/backend-api/models');
      res.writeHead(result.ok ? 200 : 500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result.data || { error: result.text }));
      return;
    }

    // GET /conversations
    if (req.method === 'GET' && url.pathname === '/conversations') {
      const result = await browserFetch('/backend-api/conversations?limit=28&order=updated');
      res.writeHead(result.ok ? 200 : 500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result.data || { error: result.text }));
      return;
    }

    // POST /chat
    if (req.method === 'POST' && url.pathname === '/chat') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', async () => {
        try {
          const { message, model, conversation_id } = JSON.parse(body);

          if (!message) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'message required' }));
            return;
          }

          console.log(`📨 "${message.substring(0, 40)}..."`);
          const result = await sendMessage(message, model || 'auto', conversation_id);
          console.log(`✅ "${(result.response || result.error || '').substring(0, 40)}..."`);

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify(result));
        } catch (e) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: e.message }));
        }
      });
      return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not found' }));

  } catch (e) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: e.message }));
  }
});

// Start
(async () => {
  await init();

  server.listen(PORT, () => {
    console.log(`\n🔌 Server: http://localhost:${PORT}`);
    console.log('\nEndpoints:');
    console.log('  GET  /status');
    console.log('  GET  /me');
    console.log('  GET  /models');
    console.log('  GET  /conversations');
    console.log('  POST /chat {"message": "Hello"}');
    console.log('\nTest:');
    console.log(`  curl -X POST http://localhost:${PORT}/chat -H "Content-Type: application/json" -d '{"message":"Hello"}'`);
  });

  process.on('SIGINT', async () => {
    console.log('\n👋 Bye');
    if (browser) await browser.close();
    process.exit(0);
  });
})();
