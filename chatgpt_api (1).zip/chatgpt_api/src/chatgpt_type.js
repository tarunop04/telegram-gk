/**
 * ChatGPT Type-Based API
 * Types directly into the chat UI to bypass all API protections
 */

const { chromium } = require('playwright');
const http = require('http');
const path = require('path');

const PORT = 8767;
let page = null;
let browser = null;
let isReady = false;
let isBusy = false;

async function init() {
  console.log('🚀 Starting browser...');

  browser = await chromium.launchPersistentContext(
    path.join(__dirname, '.chatgpt-session'),
    {
      headless: false,
      executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      args: ['--disable-blink-features=AutomationControlled'],
      ignoreDefaultArgs: ['--enable-automation'],
      viewport: { width: 1280, height: 900 },
    }
  );

  page = browser.pages()[0] || await browser.newPage();

  await page.addInitScript(() => {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
  });

  console.log('🌐 Opening ChatGPT...');
  await page.goto('https://chatgpt.com/', { waitUntil: 'domcontentloaded', timeout: 60000 });

  // Wait for chat interface
  console.log('⏳ Waiting for chat interface...');
  try {
    await page.waitForSelector('#prompt-textarea, textarea, [contenteditable="true"]', { timeout: 60000 });
    isReady = true;
    console.log('✅ Ready!');
  } catch (e) {
    console.log('⚠️ Chat interface not found. Please login manually.');
  }
}

async function sendMessage(message) {
  if (isBusy) {
    return { error: 'Busy processing another message' };
  }

  isBusy = true;

  try {
    // Find the input element
    const inputSelector = '#prompt-textarea, textarea[placeholder*="Message"], div[contenteditable="true"][data-placeholder]';

    // Wait for input to be ready
    await page.waitForSelector(inputSelector, { timeout: 10000 });

    // Click on the input to focus it
    const input = await page.$(inputSelector);
    if (!input) {
      return { error: 'Chat input not found' };
    }

    await input.click();
    await page.waitForTimeout(200);

    // Clear any existing text and type the message
    // Use keyboard shortcuts to select all and delete
    await page.keyboard.press('Meta+a');
    await page.keyboard.press('Backspace');
    await page.waitForTimeout(100);

    // Type the message character by character (more human-like)
    await page.keyboard.type(message, { delay: 10 });
    await page.waitForTimeout(300);

    // Find and click send button
    const sendButtonSelector = 'button[data-testid="send-button"], button[aria-label*="Send"], button:has(svg[class*="send"])';

    // Try clicking the send button
    let sent = false;
    try {
      const sendBtn = await page.$(sendButtonSelector);
      if (sendBtn) {
        const isEnabled = await sendBtn.isEnabled();
        if (isEnabled) {
          await sendBtn.click();
          sent = true;
        }
      }
    } catch (e) {}

    // If button click didn't work, try Enter key
    if (!sent) {
      await page.keyboard.press('Enter');
    }

    // Wait for response to appear
    await page.waitForTimeout(1500);

    // Wait for streaming to complete by watching for the response
    let lastContent = '';
    let stableCount = 0;
    let response = '';

    for (let i = 0; i < 120; i++) { // Max 2 minutes
      await page.waitForTimeout(1000);

      // Get the last assistant message
      const content = await page.evaluate(() => {
        // Try different selectors for assistant messages
        const selectors = [
          '[data-message-author-role="assistant"]',
          '.agent-turn .markdown',
          '.prose',
          '[class*="assistant"] [class*="markdown"]'
        ];

        for (const selector of selectors) {
          const elements = document.querySelectorAll(selector);
          if (elements.length > 0) {
            const lastEl = elements[elements.length - 1];
            return lastEl.innerText || lastEl.textContent || '';
          }
        }

        return '';
      });

      if (content && content === lastContent) {
        stableCount++;
        // Response stable for 3 seconds = done
        if (stableCount >= 3) {
          response = content;
          break;
        }
      } else {
        stableCount = 0;
        lastContent = content;
        response = content;
      }

      // Check if there's a "Stop" button (still generating)
      const isGenerating = await page.evaluate(() => {
        return !!document.querySelector('button[aria-label*="Stop"]');
      });

      if (!isGenerating && content && stableCount >= 1) {
        response = content;
        break;
      }
    }

    return { response };

  } catch (e) {
    return { error: e.message };
  } finally {
    isBusy = false;
  }
}

async function newChat() {
  try {
    // Click "New chat" button
    const newChatBtn = await page.$('a[href="/"], button:has-text("New chat"), [data-testid="new-chat-button"]');
    if (newChatBtn) {
      await newChatBtn.click();
      await page.waitForTimeout(1000);
      return { success: true };
    }

    // Or navigate directly
    await page.goto('https://chatgpt.com/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(1000);
    return { success: true };

  } catch (e) {
    return { error: e.message };
  }
}

// HTTP Server
const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://localhost:${PORT}`);

  // GET /status
  if (req.method === 'GET' && url.pathname === '/status') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ready: isReady,
      busy: isBusy,
      url: page ? await page.url() : null
    }));
    return;
  }

  // POST /new
  if (req.method === 'POST' && url.pathname === '/new') {
    const result = await newChat();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(result));
    return;
  }

  // POST /chat
  if (req.method === 'POST' && url.pathname === '/chat') {
    if (!isReady) {
      res.writeHead(503, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not ready - please login in browser' }));
      return;
    }

    if (isBusy) {
      res.writeHead(429, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Busy - wait for current request to finish' }));
      return;
    }

    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
      try {
        const { message } = JSON.parse(body);

        if (!message) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'message required' }));
          return;
        }

        console.log(`📨 Sending: "${message.substring(0, 50)}${message.length > 50 ? '...' : ''}"`);

        const result = await sendMessage(message);

        if (result.response) {
          console.log(`✅ Response: "${result.response.substring(0, 50)}..."`);
        } else if (result.error) {
          console.log(`❌ Error: ${result.error}`);
        }

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));

      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // GET /screenshot (for debugging)
  if (req.method === 'GET' && url.pathname === '/screenshot') {
    try {
      const screenshot = await page.screenshot({ encoding: 'base64' });
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(`<img src="data:image/png;base64,${screenshot}" style="max-width:100%">`);
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: e.message }));
    }
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

// Start
(async () => {
  await init();

  server.listen(PORT, () => {
    console.log(`\n🔌 Server: http://localhost:${PORT}`);
    console.log('\nEndpoints:');
    console.log('  GET  /status      - Check status');
    console.log('  POST /chat        - Send message');
    console.log('  POST /new         - Start new chat');
    console.log('  GET  /screenshot  - Debug screenshot');
    console.log('\nExample:');
    console.log(`  curl -X POST http://localhost:${PORT}/chat -H "Content-Type: application/json" -d '{"message":"Hello!"}'`);
  });

  process.on('SIGINT', async () => {
    console.log('\n👋 Bye');
    if (browser) await browser.close();
    process.exit(0);
  });
})();
