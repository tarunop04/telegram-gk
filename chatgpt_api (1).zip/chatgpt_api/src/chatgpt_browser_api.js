/**
 * ChatGPT Browser API Server
 *
 * Runs a real browser that handles Turnstile/Sentinel,
 * exposes a local HTTP API for Python to call.
 *
 * Usage:
 *   node chatgpt_browser_api.js
 *
 * Then from Python:
 *   requests.post('http://localhost:8765/chat', json={'message': 'Hello'})
 */

const { chromium } = require('playwright');
const http = require('http');
const path = require('path');

const PORT = 8765;
let page = null;
let browser = null;
let isReady = false;
let accessToken = null;

async function initBrowser() {
  console.log('🚀 Starting browser...');

  browser = await chromium.launchPersistentContext(
    path.join(__dirname, '.chatgpt-session'),
    {
      headless: false,
      executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      args: [
        '--disable-blink-features=AutomationControlled',
        '--window-size=1200,800',
      ],
      ignoreDefaultArgs: ['--enable-automation'],
      viewport: { width: 1200, height: 800 },
    }
  );

  page = browser.pages()[0] || await browser.newPage();

  // Remove automation flags
  await page.addInitScript(() => {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    delete navigator.__proto__.webdriver;
  });

  // Capture access token from requests
  page.on('request', req => {
    const auth = req.headers()['authorization'];
    if (auth && auth.startsWith('Bearer ')) {
      accessToken = auth.replace('Bearer ', '');
    }
  });

  console.log('🌐 Navigating to ChatGPT...');
  await page.goto('https://chatgpt.com/', { waitUntil: 'domcontentloaded' });

  // Wait for page to be ready (check for textarea or login button)
  console.log('⏳ Waiting for page to load...');
  console.log('   Complete Cloudflare check and login if needed');

  try {
    // Wait for either the chat input or logged-in state
    await page.waitForFunction(() => {
      return document.querySelector('textarea') ||
             document.querySelector('[data-testid="send-button"]') ||
             document.querySelector('#prompt-textarea');
    }, { timeout: 120000 });

    isReady = true;
    console.log('✅ ChatGPT is ready!');
    console.log(`🔌 API server running at http://localhost:${PORT}`);
    console.log('');
    console.log('Endpoints:');
    console.log('  POST /chat     - Send a message');
    console.log('  GET  /status   - Check status');
    console.log('  GET  /models   - Get available models');
    console.log('');
  } catch (e) {
    console.log('⚠️  Timeout waiting for ChatGPT. Please login manually.');
    console.log('   The API will work once you\'re logged in.');
  }
}

// Send a message using the browser
async function sendMessage(message, model = 'auto') {
  if (!isReady || !page) {
    throw new Error('Browser not ready');
  }

  // Use the browser's fetch API directly (has all cookies/tokens)
  const result = await page.evaluate(async ({ message, model }) => {
    // Get the current conversation state from React
    const getReactState = () => {
      const root = document.getElementById('__next');
      if (!root || !root._reactRootContainer) return null;
      // Try to find conversation context
      return null;
    };

    // Generate UUIDs
    const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });

    const messageId = uuid();
    const parentId = uuid();

    // Build payload matching browser format
    const payload = {
      action: 'next',
      messages: [{
        id: messageId,
        author: { role: 'user' },
        content: { content_type: 'text', parts: [message] },
        metadata: {
          serialization_metadata: { custom_symbol_offsets: [] }
        }
      }],
      parent_message_id: parentId,
      model: model,
      timezone_offset_min: new Date().getTimezoneOffset(),
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      conversation_mode: { kind: 'primary_assistant' },
      client_prepare_state: 'success',
      enable_message_followups: true,
      system_hints: [],
      supports_buffering: true,
      supported_encodings: ['v1'],
      client_contextual_info: {
        is_dark_mode: window.matchMedia('(prefers-color-scheme: dark)').matches,
        time_since_loaded: performance.now() / 1000 | 0,
        page_height: window.innerHeight,
        page_width: window.innerWidth,
        pixel_ratio: window.devicePixelRatio,
        screen_height: screen.height,
        screen_width: screen.width
      }
    };

    try {
      // First, prepare the chat requirements
      const prepareResp = await fetch('/backend-api/sentinel/chat-requirements/prepare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(null),
        credentials: 'include'
      });

      if (!prepareResp.ok) {
        return { error: `Prepare failed: ${prepareResp.status}` };
      }

      const prepareData = await prepareResp.json();

      // Get tokens from SentinelSDK if available
      let chatToken = null;
      if (window.SentinelSDK && window.SentinelSDK.token) {
        try {
          chatToken = await window.SentinelSDK.token();
        } catch (e) {
          console.log('SentinelSDK.token() failed:', e);
        }
      }

      // Try the conversation endpoint
      const resp = await fetch('/backend-api/conversation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'text/event-stream',
          ...(chatToken && { 'openai-sentinel-chat-requirements-token': chatToken })
        },
        body: JSON.stringify(payload),
        credentials: 'include'
      });

      if (!resp.ok) {
        const text = await resp.text();
        return { error: `HTTP ${resp.status}: ${text.substring(0, 200)}` };
      }

      // Read streaming response
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let fullText = '';
      let conversationId = null;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') continue;

            try {
              const parsed = JSON.parse(data);
              if (parsed.message?.content?.parts) {
                fullText = parsed.message.content.parts[0] || '';
              }
              if (parsed.conversation_id) {
                conversationId = parsed.conversation_id;
              }
            } catch (e) {}
          }
        }
      }

      return {
        response: fullText,
        conversation_id: conversationId
      };

    } catch (e) {
      return { error: e.message };
    }
  }, { message, model });

  return result;
}

// Alternative: Type message directly into the UI
async function sendMessageViaUI(message) {
  if (!isReady || !page) {
    throw new Error('Browser not ready');
  }

  // Find and fill the textarea
  const textarea = await page.$('textarea, #prompt-textarea, [data-testid="composer-input"]');
  if (!textarea) {
    throw new Error('Chat input not found');
  }

  // Clear and type
  await textarea.fill('');
  await textarea.fill(message);

  // Wait a bit for any debouncing
  await page.waitForTimeout(100);

  // Find and click send button
  const sendButton = await page.$('[data-testid="send-button"], button[aria-label*="Send"]');
  if (sendButton) {
    await sendButton.click();
  } else {
    // Try pressing Enter
    await textarea.press('Enter');
  }

  // Wait for response to appear
  await page.waitForTimeout(1000);

  // Wait for the response to finish (streaming stops)
  let lastText = '';
  let stableCount = 0;

  for (let i = 0; i < 60; i++) { // Max 60 seconds
    await page.waitForTimeout(1000);

    // Get the last assistant message
    const response = await page.evaluate(() => {
      const messages = document.querySelectorAll('[data-message-author-role="assistant"]');
      const lastMsg = messages[messages.length - 1];
      return lastMsg ? lastMsg.innerText : '';
    });

    if (response === lastText && response.length > 0) {
      stableCount++;
      if (stableCount >= 2) { // Stable for 2 seconds
        return { response };
      }
    } else {
      stableCount = 0;
      lastText = response;
    }
  }

  return { response: lastText || 'Timeout waiting for response' };
}

// HTTP Server
const server = http.createServer(async (req, res) => {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://localhost:${PORT}`);

  // GET /status
  if (req.method === 'GET' && url.pathname === '/status') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ready: isReady,
      hasToken: !!accessToken,
      url: page ? await page.url() : null
    }));
    return;
  }

  // GET /models
  if (req.method === 'GET' && url.pathname === '/models') {
    if (!isReady) {
      res.writeHead(503, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not ready' }));
      return;
    }

    try {
      const models = await page.evaluate(async () => {
        const r = await fetch('/backend-api/models', { credentials: 'include' });
        return r.json();
      });
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(models));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: e.message }));
    }
    return;
  }

  // POST /chat
  if (req.method === 'POST' && url.pathname === '/chat') {
    if (!isReady) {
      res.writeHead(503, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Browser not ready. Complete login first.' }));
      return;
    }

    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
      try {
        const { message, model, method } = JSON.parse(body);

        if (!message) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'message is required' }));
          return;
        }

        console.log(`📨 Sending: "${message.substring(0, 50)}..."`);

        let result;
        if (method === 'ui') {
          result = await sendMessageViaUI(message);
        } else {
          result = await sendMessage(message, model || 'auto');

          // If API fails, fallback to UI method
          if (result.error) {
            console.log('⚠️  API method failed, trying UI method...');
            result = await sendMessageViaUI(message);
          }
        }

        console.log(`✅ Response: "${(result.response || result.error || '').substring(0, 50)}..."`);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // POST /conversations
  if (req.method === 'GET' && url.pathname === '/conversations') {
    if (!isReady) {
      res.writeHead(503, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not ready' }));
      return;
    }

    try {
      const data = await page.evaluate(async () => {
        const r = await fetch('/backend-api/conversations?limit=28', { credentials: 'include' });
        return r.json();
      });
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(data));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: e.message }));
    }
    return;
  }

  // GET /me
  if (req.method === 'GET' && url.pathname === '/me') {
    if (!isReady) {
      res.writeHead(503, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not ready' }));
      return;
    }

    try {
      const data = await page.evaluate(async () => {
        const r = await fetch('/backend-api/me', { credentials: 'include' });
        return r.json();
      });
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(data));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: e.message }));
    }
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

// Start everything
(async () => {
  await initBrowser();

  server.listen(PORT, () => {
    console.log('');
    console.log('=' .repeat(50));
    console.log('Test with:');
    console.log(`  curl http://localhost:${PORT}/status`);
    console.log(`  curl -X POST http://localhost:${PORT}/chat -H "Content-Type: application/json" -d '{"message":"Hello!"}'`);
    console.log('=' .repeat(50));
  });

  // Handle exit
  process.on('SIGINT', async () => {
    console.log('\n👋 Shutting down...');
    if (browser) await browser.close();
    process.exit(0);
  });
})();
