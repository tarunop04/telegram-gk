#!/bin/bash
# ChatGPT Traffic Capture Automation
# Captures all API endpoints by navigating through the app

set -e
cd "$(dirname "$0")"

echo "========================================"
echo "ChatGPT API Traffic Capture"
echo "========================================"

# Get host IP for proxy
HOST_IP=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | head -1 | awk '{print $2}')
PROXY_PORT=8080

echo "[1] Host IP: $HOST_IP"
echo "[2] Proxy Port: $PROXY_PORT"

# Check device connection
echo ""
echo "[3] Checking device connection..."
adb devices | grep -q "device$" || { echo "No device connected!"; exit 1; }
DEVICE_ID=$(adb devices | grep "device$" | head -1 | cut -f1)
echo "    Device: $DEVICE_ID"

# Check if frida-server is on device
echo ""
echo "[4] Checking frida-server on device..."
FRIDA_SERVER=$(adb shell "su -c 'ls /data/local/tmp/frida-server*'" 2>/dev/null | head -1 | tr -d '\r')

if [ -z "$FRIDA_SERVER" ]; then
    echo "    frida-server not found. Downloading..."

    # Get device architecture
    ARCH=$(adb shell getprop ro.product.cpu.abi | tr -d '\r')
    echo "    Device arch: $ARCH"

    # Map to frida arch
    case "$ARCH" in
        arm64-v8a) FRIDA_ARCH="arm64" ;;
        armeabi-v7a) FRIDA_ARCH="arm" ;;
        x86_64) FRIDA_ARCH="x86_64" ;;
        x86) FRIDA_ARCH="x86" ;;
        *) echo "Unknown arch: $ARCH"; exit 1 ;;
    esac

    # Download frida-server
    FRIDA_VERSION=$(frida --version 2>/dev/null || echo "16.5.9")
    FRIDA_URL="https://github.com/frida/frida/releases/download/${FRIDA_VERSION}/frida-server-${FRIDA_VERSION}-android-${FRIDA_ARCH}.xz"

    echo "    Downloading frida-server ${FRIDA_VERSION} for ${FRIDA_ARCH}..."
    curl -sL "$FRIDA_URL" -o /tmp/frida-server.xz
    xz -d -f /tmp/frida-server.xz

    echo "    Pushing to device..."
    adb push /tmp/frida-server /data/local/tmp/frida-server
    adb shell "su -c 'chmod 755 /data/local/tmp/frida-server'"
    FRIDA_SERVER="/data/local/tmp/frida-server"
fi

echo "    frida-server: $FRIDA_SERVER"

# Kill any existing frida-server
adb shell "su -c 'pkill -f frida-server'" 2>/dev/null || true
sleep 1

# Start frida-server
echo ""
echo "[5] Starting frida-server..."
adb shell "su -c '$FRIDA_SERVER -D &'" &
sleep 2

# Verify frida-server
frida-ps -U > /dev/null 2>&1 || { echo "frida-server not responding!"; exit 1; }
echo "    frida-server running"

# Install mitmproxy cert on device (if not done)
echo ""
echo "[6] Setting up proxy certificate..."
CERT_FILE=~/.mitmproxy/mitmproxy-ca-cert.cer

if [ ! -f "$CERT_FILE" ]; then
    echo "    Generating mitmproxy certificate..."
    timeout 3 mitmdump > /dev/null 2>&1 || true
fi

if [ -f "$CERT_FILE" ]; then
    # Convert to Android format
    HASH=$(openssl x509 -inform PEM -subject_hash_old -in "$CERT_FILE" | head -1)
    cp "$CERT_FILE" "/tmp/${HASH}.0"

    echo "    Pushing certificate to device..."
    adb push "/tmp/${HASH}.0" /sdcard/
    adb shell "su -c 'mount -o rw,remount /system'" 2>/dev/null || true
    adb shell "su -c 'cp /sdcard/${HASH}.0 /system/etc/security/cacerts/'" 2>/dev/null || true
    adb shell "su -c 'chmod 644 /system/etc/security/cacerts/${HASH}.0'" 2>/dev/null || true
    echo "    Certificate installed (may need reboot)"
fi

# Configure device proxy
echo ""
echo "[7] Configuring device proxy..."
adb shell settings put global http_proxy "$HOST_IP:$PROXY_PORT"
echo "    Proxy set to $HOST_IP:$PROXY_PORT"

# Clear old capture data
echo ""
echo "[8] Clearing old capture data..."
rm -f captured_endpoints.json captured_traffic.jsonl
echo "    Cleared"

# Start mitmproxy in background
echo ""
echo "[9] Starting mitmproxy..."
mitmdump -s capture_traffic.py -p $PROXY_PORT --set block_global=false 2>&1 &
MITM_PID=$!
sleep 2
echo "    mitmproxy running (PID: $MITM_PID)"

# Launch ChatGPT with Frida
echo ""
echo "[10] Launching ChatGPT with SSL bypass..."
frida -U -f com.openai.chatgpt -l ssl_bypass.js -l frida_intercept.js --no-pause &
FRIDA_PID=$!
sleep 5
echo "     App launched with Frida"

# Cleanup function
cleanup() {
    echo ""
    echo "[CLEANUP] Stopping services..."
    kill $MITM_PID 2>/dev/null || true
    kill $FRIDA_PID 2>/dev/null || true
    adb shell settings put global http_proxy :0
    adb shell "su -c 'pkill -f frida-server'" 2>/dev/null || true
    echo "[CLEANUP] Done"
}
trap cleanup EXIT

echo ""
echo "========================================"
echo "CAPTURE RUNNING"
echo "========================================"
echo ""
echo "Now navigate through the ChatGPT app:"
echo "  1. Log in with your credentials"
echo "  2. Start a new chat"
echo "  3. Send messages"
echo "  4. Try voice mode"
echo "  5. Check settings"
echo "  6. View conversation history"
echo ""
echo "Press Ctrl+C when done to stop capture."
echo ""
echo "Captured endpoints will be saved to:"
echo "  - captured_endpoints.json"
echo "  - captured_traffic.jsonl"
echo ""

# Wait for user to finish
wait $MITM_PID
