const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const os = require('os');

(async () => {
  const capturedData = {
    cookies: [],
    localStorage: {},
    sessionStorage: {},
    authTokens: {},
    apiCalls: [],
  };

  console.log('🚀 Launching with REAL Chrome profile...');
  console.log('📝 This uses your actual Chrome data - no bot detection!\n');

  // Find Chrome profile path on macOS
  const chromeProfilePath = path.join(
    os.homedir(),
    'Library/Application Support/Google/Chrome'
  );

  // Check if Chrome profile exists
  if (!fs.existsSync(chromeProfilePath)) {
    console.log('⚠️  Chrome profile not found. Using clean profile instead.');
  }

  // Launch using Chrome's debugging protocol
  // First, we need to launch Chrome with remote debugging
  const { execSync, spawn } = require('child_process');

  // Kill any existing Chrome instances that might conflict
  try {
    execSync('pkill -f "remote-debugging-port=9222"', { stdio: 'ignore' });
  } catch (e) {}

  console.log('🌐 Starting Chrome with remote debugging...');
  console.log('   (You may need to close other Chrome windows)\n');

  // Launch Chrome with debugging port
  const chromeProcess = spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', [
    '--remote-debugging-port=9222',
    '--user-data-dir=' + chromeProfilePath,
    '--profile-directory=Default',
    '--no-first-run',
    '--no-default-browser-check',
    'about:blank'
  ], {
    detached: true,
    stdio: 'ignore'
  });

  // Wait for Chrome to start
  await new Promise(r => setTimeout(r, 3000));

  // Connect to the running Chrome
  let browser;
  try {
    browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
    console.log('✅ Connected to Chrome!\n');
  } catch (e) {
    console.log('❌ Could not connect to Chrome. Trying alternative method...\n');

    // Alternative: Launch Chromium with stealth settings
    browser = await chromium.launchPersistentContext(
      path.join(__dirname, '.chrome-profile'),
      {
        headless: false,
        executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        args: [
          '--disable-blink-features=AutomationControlled',
          '--start-maximized',
        ],
        ignoreDefaultArgs: ['--enable-automation', '--enable-blink-features=AutomationControlled'],
        viewport: null,
      }
    );
  }

  const context = browser.contexts ? browser.contexts()[0] : browser;
  const page = context.pages ? context.pages()[0] : (await context.newPage());

  // Override automation flags
  await page.addInitScript(() => {
    delete navigator.__proto__.webdriver;
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
  });

  // Capture network traffic
  page.on('request', request => {
    const url = request.url();
    const method = request.method();
    const headers = request.headers();
    const postData = request.postData();

    if (url.includes('/backend-api') || url.includes('/backend-anon')) {
      const entry = {
        timestamp: new Date().toISOString(),
        method,
        url,
        headers,
        body: postData ? tryParse(postData) : null,
      };
      capturedData.apiCalls.push(entry);

      console.log(`📡 ${method} ${url.split('chatgpt.com')[1] || url}`);

      if (headers['authorization']) {
        capturedData.authTokens.authorization = headers['authorization'];
        console.log(`   🔑 Authorization: ${headers['authorization'].substring(0, 50)}...`);
      }
      if (headers['openai-sentinel-chat-requirements-token']) {
        capturedData.authTokens.sentinel = headers['openai-sentinel-chat-requirements-token'];
      }
    }
  });

  page.on('response', async response => {
    const url = response.url();
    if (url.includes('/backend-api') || url.includes('/backend-anon')) {
      try {
        const body = await response.json().catch(() => null);
        const match = capturedData.apiCalls.find(c => c.url === url && !c.response);
        if (match) {
          match.response = { status: response.status(), body };
        }
        if (body?.accessToken) {
          capturedData.authTokens.accessToken = body.accessToken;
          console.log(`   🔑 AccessToken found!`);
        }
      } catch (e) {}
    }
  });

  function tryParse(str) {
    try { return JSON.parse(str); } catch { return str; }
  }

  // Save function
  const saveAndExit = async () => {
    console.log('\n\n📊 Saving captured data...');

    try {
      capturedData.cookies = await context.cookies();
    } catch (e) {
      console.log('   ⚠️  Could not get cookies from CDP connection');
    }

    try {
      capturedData.localStorage = await page.evaluate(() => ({ ...localStorage }));
      capturedData.sessionStorage = await page.evaluate(() => ({ ...sessionStorage }));
    } catch (e) {}

    // Save raw data
    fs.writeFileSync('chatgpt_capture.json', JSON.stringify(capturedData, null, 2));
    console.log('✅ Saved to chatgpt_capture.json');

    // Generate Python client
    generateClient(capturedData);

    // Generate API documentation
    generateDocs(capturedData);

    try {
      await browser.close();
    } catch (e) {}

    process.exit(0);
  };

  function generateClient(data) {
    const token = data.authTokens.authorization?.replace('Bearer ', '') ||
                  data.authTokens.accessToken || '';
    const cookies = {};
    (data.cookies || []).forEach(c => cookies[c.name] = c.value);

    const code = `#!/usr/bin/env python3
"""
ChatGPT Web API Client
Reverse-engineered from browser session
"""
import requests
import json
import uuid
from typing import Generator, Optional

class ChatGPTWebClient:
    """Client for ChatGPT web interface API"""

    BASE_URL = "https://chatgpt.com"

    def __init__(self, access_token: str = None, cookies: dict = None):
        self.session = requests.Session()

        # From captured session
        self.access_token = access_token or "${token}"
        self._cookies = cookies or ${JSON.stringify(cookies, null, 12)}

        # Apply cookies
        for name, value in self._cookies.items():
            self.session.cookies.set(name, value, domain=".chatgpt.com")

        # Standard headers
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/json",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://chatgpt.com/",
            "Origin": "https://chatgpt.com",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
        })

        if self.access_token:
            self.session.headers["Authorization"] = f"Bearer {self.access_token}"

    # ==================== USER & ACCOUNT ====================

    def get_me(self) -> dict:
        """Get current user info"""
        r = self.session.get(f"{self.BASE_URL}/backend-api/me")
        r.raise_for_status()
        return r.json()

    def get_accounts(self) -> dict:
        """Get account info"""
        r = self.session.get(f"{self.BASE_URL}/backend-api/accounts/check")
        return r.json()

    # ==================== MODELS ====================

    def get_models(self) -> dict:
        """Get available models"""
        r = self.session.get(f"{self.BASE_URL}/backend-api/models")
        r.raise_for_status()
        return r.json()

    # ==================== CONVERSATIONS ====================

    def list_conversations(self, offset: int = 0, limit: int = 28) -> dict:
        """List all conversations"""
        r = self.session.get(
            f"{self.BASE_URL}/backend-api/conversations",
            params={"offset": offset, "limit": limit, "order": "updated"}
        )
        r.raise_for_status()
        return r.json()

    def get_conversation(self, conversation_id: str) -> dict:
        """Get a specific conversation with all messages"""
        r = self.session.get(f"{self.BASE_URL}/backend-api/conversation/{conversation_id}")
        r.raise_for_status()
        return r.json()

    def delete_conversation(self, conversation_id: str) -> dict:
        """Delete/hide a conversation"""
        r = self.session.patch(
            f"{self.BASE_URL}/backend-api/conversation/{conversation_id}",
            json={"is_visible": False}
        )
        return r.json()

    def rename_conversation(self, conversation_id: str, title: str) -> dict:
        """Rename a conversation"""
        r = self.session.patch(
            f"{self.BASE_URL}/backend-api/conversation/{conversation_id}",
            json={"title": title}
        )
        return r.json()

    # ==================== CHAT / MESSAGES ====================

    def send_message(
        self,
        message: str,
        conversation_id: Optional[str] = None,
        parent_message_id: Optional[str] = None,
        model: str = "auto",
    ) -> Generator[dict, None, None]:
        """
        Send a message and stream the response.

        Args:
            message: The user message
            conversation_id: Existing conversation ID (None for new)
            parent_message_id: Parent message ID (None = new conversation)
            model: Model slug (auto, gpt-4, gpt-4o, gpt-4o-mini, o1, etc.)

        Yields:
            Response chunks containing message parts
        """
        msg_id = str(uuid.uuid4())
        parent_id = parent_message_id or str(uuid.uuid4())

        payload = {
            "action": "next",
            "messages": [{
                "id": msg_id,
                "author": {"role": "user"},
                "content": {"content_type": "text", "parts": [message]},
                "metadata": {}
            }],
            "parent_message_id": parent_id,
            "model": model,
            "timezone_offset_min": -480,
            "history_and_training_disabled": False,
            "conversation_mode": {"kind": "primary_assistant"},
            "force_paragen": False,
            "force_rate_limit": False,
            "websocket_request_id": str(uuid.uuid4()),
        }

        if conversation_id:
            payload["conversation_id"] = conversation_id

        r = self.session.post(
            f"{self.BASE_URL}/backend-api/conversation",
            json=payload,
            headers={"Accept": "text/event-stream"},
            stream=True
        )
        r.raise_for_status()

        for line in r.iter_lines():
            if not line:
                continue
            line = line.decode("utf-8")
            if line.startswith("data: "):
                data = line[6:]
                if data == "[DONE]":
                    break
                try:
                    yield json.loads(data)
                except json.JSONDecodeError:
                    continue

    def send_message_simple(self, message: str, **kwargs) -> str:
        """Send message and return just the final text response"""
        full_text = ""
        conv_id = None
        for chunk in self.send_message(message, **kwargs):
            if "message" in chunk:
                msg = chunk["message"]
                if msg.get("content", {}).get("parts"):
                    full_text = msg["content"]["parts"][0]
                if "conversation_id" in chunk:
                    conv_id = chunk["conversation_id"]
        return full_text

    # ==================== MISC ====================

    def get_prompt_library(self) -> dict:
        """Get suggested prompts"""
        r = self.session.get(f"{self.BASE_URL}/backend-api/prompt_library/")
        return r.json()

    def generate_title(self, conversation_id: str, message_id: str) -> dict:
        """Generate title for conversation"""
        r = self.session.post(
            f"{self.BASE_URL}/backend-api/conversation/gen_title/{conversation_id}",
            json={"message_id": message_id}
        )
        return r.json()


# ==================== EXAMPLE USAGE ====================

if __name__ == "__main__":
    client = ChatGPTWebClient()

    print("=" * 50)
    print("ChatGPT Web API Client Test")
    print("=" * 50)

    try:
        # Test auth
        me = client.get_me()
        print(f"\\n✅ Logged in as: {me.get('email', 'Unknown')}")
        print(f"   Name: {me.get('name', 'N/A')}")

        # Get models
        models = client.get_models()
        model_names = [m.get('slug') for m in models.get('models', [])]
        print(f"\\n📦 Available models: {model_names}")

        # List recent conversations
        convos = client.list_conversations(limit=5)
        print(f"\\n💬 Recent conversations:")
        for c in convos.get('items', [])[:5]:
            print(f"   - {c.get('title', 'Untitled')[:40]}")

        # Send a test message
        print("\\n🤖 Sending test message...")
        response = client.send_message_simple("Say 'API test successful!' and nothing else.")
        print(f"   Response: {response[:100]}")

        print("\\n✅ All tests passed!")

    except requests.exceptions.HTTPError as e:
        print(f"\\n❌ HTTP Error: {e}")
        print("   Token may be expired. Re-run the capture script.")
    except Exception as e:
        print(f"\\n❌ Error: {e}")
`;

    fs.writeFileSync('chatgpt_client.py', code);
    console.log('✅ Generated chatgpt_client.py');
  }

  function generateDocs(data) {
    let doc = `# ChatGPT Web API Documentation

Generated: ${new Date().toISOString()}

## Authentication

ChatGPT uses Bearer token authentication. The access token is obtained after login
and sent in the \`Authorization\` header.

\`\`\`
Authorization: Bearer <access_token>
\`\`\`

## Captured Endpoints

`;

    const endpoints = new Map();
    data.apiCalls.forEach(call => {
      const key = `${call.method} ${call.url.split('?')[0]}`;
      if (!endpoints.has(key)) {
        endpoints.set(key, call);
      }
    });

    endpoints.forEach((call, key) => {
      doc += `### ${key.replace('https://chatgpt.com', '')}\n\n`;
      doc += `**Method:** ${call.method}\n\n`;
      if (call.body) {
        doc += `**Request Body:**\n\`\`\`json\n${JSON.stringify(call.body, null, 2).substring(0, 500)}\n\`\`\`\n\n`;
      }
      if (call.response?.body) {
        doc += `**Response:**\n\`\`\`json\n${JSON.stringify(call.response.body, null, 2).substring(0, 500)}\n\`\`\`\n\n`;
      }
      doc += '---\n\n';
    });

    fs.writeFileSync('CHATGPT_API.md', doc);
    console.log('✅ Generated CHATGPT_API.md');
  }

  process.on('SIGINT', saveAndExit);
  process.on('SIGTERM', saveAndExit);

  // Navigate to ChatGPT
  console.log('🌐 Opening ChatGPT...');
  await page.goto('https://chatgpt.com/', { waitUntil: 'domcontentloaded', timeout: 60000 });

  console.log('\n✅ Browser ready!');
  console.log('');
  console.log('📋 INSTRUCTIONS:');
  console.log('   1. Complete Cloudflare check if shown (click checkbox)');
  console.log('   2. Log in if needed');
  console.log('   3. Send a test message to capture the full API');
  console.log('   4. Press Ctrl+C to save everything');
  console.log('');

  await new Promise(() => {});
})();
