const { chromium } = require('playwright');
const fs = require('fs');

(async () => {
  const endpoints = [];
  const websockets = [];
  const requestDetails = [];

  console.log('🚀 Launching browser...');
  console.log('📝 Please log in to ChatGPT manually');
  console.log('💡 The script will capture all network traffic');
  console.log('⏹️  Press Ctrl+C when done exploring\n');

  const browser = await chromium.launch({
    headless: false,
    args: ['--start-maximized']
  });

  const context = await browser.newContext({
    viewport: null,
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  });

  const page = await context.newPage();

  // Capture all network requests
  page.on('request', request => {
    const url = request.url();
    const method = request.method();
    const headers = request.headers();
    const postData = request.postData();

    const entry = {
      timestamp: new Date().toISOString(),
      method,
      url,
      headers,
      postData: postData ? (postData.length > 1000 ? postData.substring(0, 1000) + '...' : postData) : null
    };

    requestDetails.push(entry);

    // Extract unique endpoints
    try {
      const urlObj = new URL(url);
      const endpoint = `${method} ${urlObj.origin}${urlObj.pathname}`;
      if (!endpoints.includes(endpoint)) {
        endpoints.push(endpoint);
        console.log(`📡 ${endpoint}`);
      }
    } catch (e) {}
  });

  // Capture responses
  page.on('response', async response => {
    const url = response.url();
    const status = response.status();
    const contentType = response.headers()['content-type'] || '';

    // Log interesting API responses
    if (url.includes('/backend-api') || url.includes('/api/')) {
      console.log(`  ↳ ${status} ${contentType.split(';')[0]}`);
    }
  });

  // Capture WebSocket connections
  page.on('websocket', ws => {
    const url = ws.url();
    console.log(`🔌 WebSocket: ${url}`);
    websockets.push({ url, messages: [] });

    ws.on('framereceived', frame => {
      const wsEntry = websockets.find(w => w.url === url);
      if (wsEntry && frame.payload) {
        wsEntry.messages.push({
          direction: 'received',
          timestamp: new Date().toISOString(),
          payload: frame.payload.length > 500 ? frame.payload.substring(0, 500) + '...' : frame.payload
        });
      }
    });

    ws.on('framesent', frame => {
      const wsEntry = websockets.find(w => w.url === url);
      if (wsEntry && frame.payload) {
        wsEntry.messages.push({
          direction: 'sent',
          timestamp: new Date().toISOString(),
          payload: frame.payload.length > 500 ? frame.payload.substring(0, 500) + '...' : frame.payload
        });
      }
    });
  });

  // Handle script termination
  const saveAndExit = async () => {
    console.log('\n\n📊 Saving captured data...');

    // Group endpoints by domain
    const grouped = {};
    endpoints.forEach(ep => {
      const match = ep.match(/^(\w+) (https?:\/\/[^\/]+)/);
      if (match) {
        const domain = match[2];
        if (!grouped[domain]) grouped[domain] = [];
        grouped[domain].push(ep);
      }
    });

    const report = {
      capturedAt: new Date().toISOString(),
      summary: {
        totalEndpoints: endpoints.length,
        totalRequests: requestDetails.length,
        websocketConnections: websockets.length
      },
      endpointsByDomain: grouped,
      allEndpoints: endpoints,
      websockets,
      requestDetails: requestDetails.slice(-200) // Last 200 requests
    };

    fs.writeFileSync('chatgpt_endpoints.json', JSON.stringify(report, null, 2));
    console.log('✅ Saved to chatgpt_endpoints.json');

    // Print summary
    console.log('\n' + '='.repeat(60));
    console.log('ENDPOINT SUMMARY');
    console.log('='.repeat(60));

    Object.entries(grouped).forEach(([domain, eps]) => {
      console.log(`\n🌐 ${domain}`);
      eps.forEach(ep => console.log(`   ${ep.replace(domain, '')}`));
    });

    console.log('\n' + '='.repeat(60));
    console.log(`Total: ${endpoints.length} unique endpoints`);
    console.log(`WebSockets: ${websockets.length} connections`);
    console.log('='.repeat(60));

    await browser.close();
    process.exit(0);
  };

  process.on('SIGINT', saveAndExit);
  process.on('SIGTERM', saveAndExit);

  // Navigate to ChatGPT
  await page.goto('https://chatgpt.com/', { waitUntil: 'domcontentloaded', timeout: 60000 });

  console.log('\n✅ Page loaded. Please log in and explore the site.');
  console.log('🔍 Try: sending messages, switching models, using plugins, etc.');
  console.log('⏹️  Press Ctrl+C when done to save the captured data.\n');

  // Keep the browser open indefinitely
  await new Promise((resolve) => {
    // Auto-save every 60 seconds as backup
    setInterval(() => {
      console.log(`\n📊 Auto-checkpoint: ${endpoints.length} endpoints captured...`);
    }, 60000);
  });
})();
