const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const fs = require('fs');
const path = require('path');

// Apply stealth plugin
chromium.use(stealth);

(async () => {
  const capturedData = {
    cookies: [],
    localStorage: {},
    sessionStorage: {},
    authTokens: {},
    apiCalls: [],
    authFlow: [],
    headers: {}
  };

  console.log('🥷 Launching STEALTH browser...');
  console.log('📝 Please log in to ChatGPT');
  console.log('💡 After login, send a test message');
  console.log('⏹️  Press Ctrl+C when done\n');

  // Use persistent context to maintain session like real browser
  const userDataDir = path.join(__dirname, '.browser-profile');

  const browser = await chromium.launchPersistentContext(userDataDir, {
    headless: false,
    channel: 'chrome',  // Use real Chrome if available
    args: [
      '--start-maximized',
      '--disable-blink-features=AutomationControlled',
      '--disable-features=IsolateOrigins,site-per-process',
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--no-first-run',
      '--no-zygote',
      '--disable-gpu',
      '--window-size=1920,1080'
    ],
    ignoreDefaultArgs: ['--enable-automation'],
    viewport: null,
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    locale: 'en-US',
    timezoneId: 'America/Los_Angeles',
  });

  const page = browser.pages()[0] || await browser.newPage();

  // Override navigator properties to look more human
  await page.addInitScript(() => {
    // Override webdriver
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });

    // Override plugins
    Object.defineProperty(navigator, 'plugins', {
      get: () => [
        { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer' },
        { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai' },
        { name: 'Native Client', filename: 'internal-nacl-plugin' }
      ]
    });

    // Override languages
    Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });

    // Override permissions
    const originalQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (parameters) =>
      parameters.name === 'notifications'
        ? Promise.resolve({ state: Notification.permission })
        : originalQuery(parameters);

    // Override chrome runtime
    window.chrome = { runtime: {} };

    // Overwrite the `navigator.vendor` property
    Object.defineProperty(navigator, 'vendor', { get: () => 'Google Inc.' });

    // Override connection
    Object.defineProperty(navigator, 'connection', {
      get: () => ({
        effectiveType: '4g',
        rtt: 50,
        downlink: 10,
        saveData: false
      })
    });
  });

  // Intercept requests
  page.on('request', async request => {
    const url = request.url();
    const method = request.method();
    const headers = request.headers();
    const postData = request.postData();

    if (url.includes('auth') || url.includes('login') || url.includes('token') ||
        url.includes('session') || url.includes('backend-api') || url.includes('backend-anon') ||
        url.includes('accounts.google') || url.includes('auth0') || url.includes('oauth')) {

      capturedData.authFlow.push({
        timestamp: new Date().toISOString(),
        type: 'request',
        method,
        url,
        headers,
        body: postData ? tryParseJSON(postData) : null
      });
      console.log(`🔐 ${method} ${url.substring(0, 80)}...`);
    }

    if (url.includes('/backend-api') || url.includes('/backend-anon')) {
      capturedData.apiCalls.push({
        timestamp: new Date().toISOString(),
        method,
        url,
        headers,
        body: postData ? tryParseJSON(postData) : null,
        response: null
      });

      if (headers['authorization']) {
        capturedData.authTokens.authorization = headers['authorization'];
        console.log(`🔑 Found Authorization header`);
      }
    }
  });

  page.on('response', async response => {
    const url = response.url();
    const status = response.status();
    const headers = response.headers();

    if (url.includes('/backend-api') || url.includes('/backend-anon')) {
      try {
        const contentType = headers['content-type'] || '';
        let body = null;

        if (contentType.includes('json')) {
          body = await response.json().catch(() => null);
        }

        const matchingCall = capturedData.apiCalls.find(c => c.url === url && !c.response);
        if (matchingCall) {
          matchingCall.response = { status, headers, body };
        }

        if (body?.accessToken) {
          capturedData.authTokens.accessToken = body.accessToken;
          console.log(`🔑 Found accessToken`);
        }

        console.log(`  ↳ ${status} ${url.split('/').slice(-2).join('/')}`);
      } catch (e) {}
    }
  });

  function tryParseJSON(str) {
    try { return JSON.parse(str); } catch { return str; }
  }

  const saveData = async () => {
    console.log('\n📊 Extracting session data...');

    capturedData.cookies = await browser.cookies();
    console.log(`  ✓ ${capturedData.cookies.length} cookies`);

    try {
      capturedData.localStorage = await page.evaluate(() => {
        const data = {};
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          data[key] = localStorage.getItem(key);
        }
        return data;
      });

      capturedData.sessionStorage = await page.evaluate(() => {
        const data = {};
        for (let i = 0; i < sessionStorage.length; i++) {
          const key = sessionStorage.key(i);
          data[key] = sessionStorage.getItem(key);
        }
        return data;
      });
      console.log(`  ✓ Storage captured`);
    } catch (e) {}

    fs.writeFileSync('chatgpt_capture.json', JSON.stringify(capturedData, null, 2));
    console.log('\n✅ Saved to chatgpt_capture.json');

    generatePythonClient(capturedData);

    await browser.close();
    process.exit(0);
  };

  function generatePythonClient(data) {
    const accessToken = data.authTokens.authorization?.replace('Bearer ', '') ||
                        data.authTokens.accessToken || 'YOUR_ACCESS_TOKEN';
    const cookies = {};
    data.cookies.forEach(c => cookies[c.name] = c.value);

    const pythonCode = `#!/usr/bin/env python3
"""ChatGPT API Client - Reverse Engineered"""
import requests
import json
import uuid

class ChatGPTClient:
    BASE_URL = "https://chatgpt.com"

    def __init__(self):
        self.session = requests.Session()
        self.access_token = "${accessToken}"
        self.cookies = ${JSON.stringify(cookies, null, 8)}

        for name, value in self.cookies.items():
            self.session.cookies.set(name, value, domain=".chatgpt.com")

        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Accept": "application/json",
            "Referer": "https://chatgpt.com/",
            "Origin": "https://chatgpt.com",
        })

        if self.access_token != "YOUR_ACCESS_TOKEN":
            self.session.headers["Authorization"] = f"Bearer {self.access_token}"

    def get_models(self):
        return self.session.get(f"{self.BASE_URL}/backend-api/models").json()

    def get_me(self):
        return self.session.get(f"{self.BASE_URL}/backend-api/me").json()

    def get_conversations(self, limit=28):
        return self.session.get(f"{self.BASE_URL}/backend-api/conversations", params={"limit": limit}).json()

    def send_message(self, message, conversation_id=None, model="auto"):
        payload = {
            "action": "next",
            "messages": [{
                "id": str(uuid.uuid4()),
                "author": {"role": "user"},
                "content": {"content_type": "text", "parts": [message]},
            }],
            "parent_message_id": str(uuid.uuid4()),
            "model": model,
            "conversation_mode": {"kind": "primary_assistant"},
        }
        if conversation_id:
            payload["conversation_id"] = conversation_id

        resp = self.session.post(
            f"{self.BASE_URL}/backend-api/conversation",
            json=payload,
            headers={"Accept": "text/event-stream"},
            stream=True
        )

        for line in resp.iter_lines():
            if line:
                line = line.decode("utf-8")
                if line.startswith("data: ") and line[6:] != "[DONE]":
                    try:
                        yield json.loads(line[6:])
                    except:
                        continue

if __name__ == "__main__":
    client = ChatGPTClient()
    print("Testing...")
    try:
        me = client.get_me()
        print(f"User: {me.get('email', me)}")
    except Exception as e:
        print(f"Error: {e}")
`;

    fs.writeFileSync('chatgpt_client.py', pythonCode);
    console.log('✅ Saved Python client to chatgpt_client.py');
  }

  process.on('SIGINT', saveData);
  process.on('SIGTERM', saveData);

  // Add random delays to appear more human
  await page.waitForTimeout(Math.random() * 1000 + 500);

  console.log('🌐 Navigating to ChatGPT...');
  await page.goto('https://chatgpt.com/', { waitUntil: 'domcontentloaded', timeout: 90000 });

  // Wait for page to stabilize
  await page.waitForTimeout(3000);

  console.log('\n✅ Page loaded!');
  console.log('');
  console.log('📋 INSTRUCTIONS:');
  console.log('   1. If Cloudflare challenge appears, complete it manually');
  console.log('   2. Log in to your ChatGPT account');
  console.log('   3. Send a test message');
  console.log('   4. Press Ctrl+C to save');
  console.log('');
  console.log('💡 TIP: This uses a persistent profile, so subsequent runs');
  console.log('   should bypass Cloudflare automatically!');
  console.log('');

  await new Promise(() => {});
})();
