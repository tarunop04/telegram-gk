
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

(async () => {
  const tokens = {
    accessToken: null,
    cookies: [],
    sentinelTokens: {},
    turnstileToken: null,
    sessionObserverToken: null,
    oaiIs: null,
  };

  console.log('🚀 Launching browser for token capture...');

  const browser = await chromium.launchPersistentContext(
    path.join(__dirname, '.chat-profile'),
    {
      headless: false,
      executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      args: ['--disable-blink-features=AutomationControlled'],
      ignoreDefaultArgs: ['--enable-automation'],
      viewport: null,
    }
  );

  const page = browser.pages()[0] || await browser.newPage();

  await page.addInitScript(() => {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
  });

  // Intercept requests to capture tokens
  page.on('request', request => {
    const headers = request.headers();
    const url = request.url();

    if (url.includes('/backend-api/') || url.includes('/backend-anon/')) {
      if (headers['authorization']) {
        tokens.accessToken = headers['authorization'].replace('Bearer ', '');
      }
      if (headers['openai-sentinel-turnstile-token']) {
        tokens.turnstileToken = headers['openai-sentinel-turnstile-token'];
        console.log('✅ Captured Turnstile token');
      }
      if (headers['x-oai-is']) {
        tokens.oaiIs = headers['x-oai-is'];
        console.log('✅ Captured x-oai-is token');
      }
      if (headers['openai-sentinel-chat-requirements-token']) {
        tokens.sentinelTokens.chatRequirements = headers['openai-sentinel-chat-requirements-token'];
      }
      if (headers['openai-sentinel-proof-token']) {
        tokens.sentinelTokens.proof = headers['openai-sentinel-proof-token'];
      }
    }

    // Capture the conversation request specifically
    if (url.includes('/f/conversation') && request.method() === 'POST') {
      console.log('📨 Captured conversation request with all tokens');
      tokens.lastConversationHeaders = headers;
    }
  });

  const saveTokens = async () => {
    tokens.cookies = await browser.cookies();
    tokens.capturedAt = new Date().toISOString();
    fs.writeFileSync('chatgpt_tokens.json', JSON.stringify(tokens, null, 2));
    console.log('\n✅ Tokens saved to chatgpt_tokens.json');
    await browser.close();
    process.exit(0);
  };

  process.on('SIGINT', saveTokens);

  await page.goto('https://chatgpt.com/', { waitUntil: 'domcontentloaded' });

  console.log('\n📋 INSTRUCTIONS:');
  console.log('   1. Complete Cloudflare verification if shown');
  console.log('   2. Log in if needed');
  console.log('   3. SEND AT LEAST ONE MESSAGE');
  console.log('   4. Press Ctrl+C to save tokens');
  console.log('\n   The tokens will be valid for ~9 minutes');
  console.log('');

  await new Promise(() => {});
})();
