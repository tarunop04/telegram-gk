const { chromium } = require('playwright');
const fs = require('fs');

(async () => {
  const capturedData = {
    cookies: [],
    localStorage: {},
    sessionStorage: {},
    authTokens: {},
    apiCalls: [],
    authFlow: [],
    headers: {}
  };

  console.log('🚀 Launching browser for full auth capture...');
  console.log('📝 Please log in to ChatGPT');
  console.log('💡 After login, send a test message to capture conversation API');
  console.log('⏹️  Press Ctrl+C when done\n');

  const browser = await chromium.launch({
    headless: false,
    args: ['--start-maximized']
  });

  const context = await browser.newContext({
    viewport: null,
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  });

  const page = await context.newPage();

  // Intercept ALL requests and responses
  page.on('request', async request => {
    const url = request.url();
    const method = request.method();
    const headers = request.headers();
    const postData = request.postData();

    // Capture auth-related requests
    if (url.includes('auth') || url.includes('login') || url.includes('token') ||
        url.includes('session') || url.includes('backend-api') || url.includes('backend-anon') ||
        url.includes('accounts.google') || url.includes('auth0') || url.includes('oauth')) {

      const entry = {
        timestamp: new Date().toISOString(),
        type: 'request',
        method,
        url,
        headers: sanitizeHeaders(headers),
        body: postData ? tryParseJSON(postData) : null
      };

      capturedData.authFlow.push(entry);
      console.log(`🔐 AUTH: ${method} ${url.substring(0, 80)}...`);
    }

    // Capture all API calls with full details
    if (url.includes('/backend-api') || url.includes('/backend-anon') || url.includes('/api/')) {
      const apiEntry = {
        timestamp: new Date().toISOString(),
        method,
        url,
        headers: sanitizeHeaders(headers),
        body: postData ? tryParseJSON(postData) : null,
        response: null
      };
      capturedData.apiCalls.push(apiEntry);

      // Extract important headers
      if (headers['authorization']) {
        capturedData.authTokens.authorization = headers['authorization'];
        console.log(`🔑 Found Authorization header`);
      }
      if (headers['openai-sentinel-chat-requirements-token']) {
        capturedData.authTokens.sentinelToken = headers['openai-sentinel-chat-requirements-token'];
        console.log(`🔑 Found Sentinel token`);
      }
    }
  });

  // Capture responses
  page.on('response', async response => {
    const url = response.url();
    const status = response.status();
    const headers = response.headers();

    if (url.includes('/backend-api') || url.includes('/backend-anon') || url.includes('/api/')) {
      try {
        const contentType = headers['content-type'] || '';
        let body = null;

        if (contentType.includes('json')) {
          body = await response.json().catch(() => null);
        } else if (contentType.includes('text')) {
          const text = await response.text().catch(() => null);
          body = text?.substring(0, 2000);
        }

        // Find matching request and add response
        const matchingCall = capturedData.apiCalls.find(c => c.url === url && !c.response);
        if (matchingCall) {
          matchingCall.response = {
            status,
            headers: sanitizeHeaders(headers),
            body
          };
        }

        // Check for tokens in response
        if (body && typeof body === 'object') {
          if (body.accessToken) {
            capturedData.authTokens.accessToken = body.accessToken;
            console.log(`🔑 Found accessToken in response`);
          }
          if (body.token) {
            capturedData.authTokens.token = body.token;
            console.log(`🔑 Found token in response`);
          }
        }

        console.log(`  ↳ ${status} ${url.split('/').slice(-2).join('/')}`);
      } catch (e) {}
    }

    // Capture auth responses
    if (url.includes('auth') || url.includes('token') || url.includes('session')) {
      try {
        const body = await response.json().catch(() => null);
        capturedData.authFlow.push({
          timestamp: new Date().toISOString(),
          type: 'response',
          url,
          status,
          headers: sanitizeHeaders(headers),
          body: body ? JSON.stringify(body).substring(0, 1000) : null
        });
      } catch (e) {}
    }
  });

  // Helper functions
  function sanitizeHeaders(headers) {
    const safe = { ...headers };
    // Keep auth headers but mark them
    return safe;
  }

  function tryParseJSON(str) {
    try {
      return JSON.parse(str);
    } catch {
      return str;
    }
  }

  // Save function
  const saveData = async () => {
    console.log('\n\n📊 Extracting session data...');

    // Get cookies
    capturedData.cookies = await context.cookies();
    console.log(`  ✓ ${capturedData.cookies.length} cookies captured`);

    // Get localStorage and sessionStorage
    try {
      capturedData.localStorage = await page.evaluate(() => {
        const data = {};
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          data[key] = localStorage.getItem(key);
        }
        return data;
      });
      console.log(`  ✓ localStorage captured`);

      capturedData.sessionStorage = await page.evaluate(() => {
        const data = {};
        for (let i = 0; i < sessionStorage.length; i++) {
          const key = sessionStorage.key(i);
          data[key] = sessionStorage.getItem(key);
        }
        return data;
      });
      console.log(`  ✓ sessionStorage captured`);
    } catch (e) {
      console.log(`  ⚠ Could not extract storage: ${e.message}`);
    }

    // Save full data
    fs.writeFileSync('chatgpt_full_capture.json', JSON.stringify(capturedData, null, 2));
    console.log('\n✅ Saved to chatgpt_full_capture.json');

    // Generate curl commands for key endpoints
    generateCurlCommands(capturedData);

    // Generate Python client
    generatePythonClient(capturedData);

    await browser.close();
    process.exit(0);
  };

  function generateCurlCommands(data) {
    let curlFile = '#!/bin/bash\n# ChatGPT API curl commands\n# Generated from captured session\n\n';

    // Extract important cookies
    const cookieStr = data.cookies.map(c => `${c.name}=${c.value}`).join('; ');

    // Find key API calls
    const keyEndpoints = data.apiCalls.filter(c =>
      c.url.includes('/backend-api') || c.url.includes('/backend-anon')
    );

    keyEndpoints.slice(0, 20).forEach((call, i) => {
      curlFile += `# ${i + 1}. ${call.method} ${call.url.split('chatgpt.com')[1] || call.url}\n`;
      curlFile += `curl -X ${call.method} '${call.url}' \\\n`;
      curlFile += `  -H 'Cookie: ${cookieStr.substring(0, 200)}...' \\\n`;

      if (call.headers['authorization']) {
        curlFile += `  -H 'Authorization: ${call.headers['authorization']}' \\\n`;
      }
      if (call.headers['content-type']) {
        curlFile += `  -H 'Content-Type: ${call.headers['content-type']}' \\\n`;
      }
      if (call.body) {
        curlFile += `  -d '${JSON.stringify(call.body).substring(0, 500)}' \\\n`;
      }
      curlFile += '\n\n';
    });

    fs.writeFileSync('chatgpt_curl_commands.sh', curlFile);
    console.log('✅ Saved curl commands to chatgpt_curl_commands.sh');
  }

  function generatePythonClient(data) {
    const accessToken = data.authTokens.authorization || data.authTokens.accessToken || 'YOUR_ACCESS_TOKEN';
    const cookies = {};
    data.cookies.forEach(c => cookies[c.name] = c.value);

    const pythonCode = `#!/usr/bin/env python3
"""
ChatGPT API Client - Reverse Engineered
Generated from captured browser session
"""
import requests
import json
import uuid
from typing import Generator

class ChatGPTClient:
    BASE_URL = "https://chatgpt.com"

    def __init__(self, access_token: str = None, cookies: dict = None):
        self.session = requests.Session()
        self.access_token = access_token or "${accessToken}"
        self.cookies = cookies or ${JSON.stringify(cookies, null, 8)}

        # Set cookies
        for name, value in self.cookies.items():
            self.session.cookies.set(name, value, domain=".chatgpt.com")

        # Default headers
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Accept": "application/json",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://chatgpt.com/",
            "Origin": "https://chatgpt.com",
        })

        if self.access_token and self.access_token != "YOUR_ACCESS_TOKEN":
            self.session.headers["Authorization"] = f"Bearer {self.access_token}"

    def get_models(self) -> dict:
        """Get available models"""
        resp = self.session.get(f"{self.BASE_URL}/backend-api/models")
        return resp.json()

    def get_me(self) -> dict:
        """Get current user info"""
        resp = self.session.get(f"{self.BASE_URL}/backend-api/me")
        return resp.json()

    def get_conversations(self, offset: int = 0, limit: int = 28) -> dict:
        """List conversations"""
        resp = self.session.get(
            f"{self.BASE_URL}/backend-api/conversations",
            params={"offset": offset, "limit": limit}
        )
        return resp.json()

    def get_conversation(self, conversation_id: str) -> dict:
        """Get a specific conversation"""
        resp = self.session.get(f"{self.BASE_URL}/backend-api/conversation/{conversation_id}")
        return resp.json()

    def send_message(
        self,
        message: str,
        conversation_id: str = None,
        parent_message_id: str = None,
        model: str = "auto"
    ) -> Generator[dict, None, None]:
        """
        Send a message and stream the response

        Args:
            message: The message to send
            conversation_id: Optional existing conversation ID
            parent_message_id: Parent message ID (required for continuing conversations)
            model: Model to use (auto, gpt-4, gpt-4o, etc.)

        Yields:
            Response chunks as they stream in
        """
        message_id = str(uuid.uuid4())
        parent_id = parent_message_id or str(uuid.uuid4())

        payload = {
            "action": "next",
            "messages": [{
                "id": message_id,
                "author": {"role": "user"},
                "content": {
                    "content_type": "text",
                    "parts": [message]
                },
                "metadata": {}
            }],
            "parent_message_id": parent_id,
            "model": model,
            "timezone_offset_min": -480,
            "suggestions": [],
            "history_and_training_disabled": False,
            "conversation_mode": {"kind": "primary_assistant"},
            "force_paragen": False,
            "force_paragen_model_slug": "",
            "force_nulligen": False,
            "force_rate_limit": False,
            "websocket_request_id": str(uuid.uuid4())
        }

        if conversation_id:
            payload["conversation_id"] = conversation_id

        headers = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }

        resp = self.session.post(
            f"{self.BASE_URL}/backend-api/conversation",
            json=payload,
            headers=headers,
            stream=True
        )

        for line in resp.iter_lines():
            if line:
                line = line.decode("utf-8")
                if line.startswith("data: "):
                    data = line[6:]
                    if data == "[DONE]":
                        break
                    try:
                        yield json.loads(data)
                    except json.JSONDecodeError:
                        continue

    def delete_conversation(self, conversation_id: str) -> dict:
        """Delete a conversation"""
        resp = self.session.patch(
            f"{self.BASE_URL}/backend-api/conversation/{conversation_id}",
            json={"is_visible": False}
        )
        return resp.json()

    def regenerate_response(self, conversation_id: str, message_id: str) -> Generator:
        """Regenerate a response"""
        payload = {
            "action": "variant",
            "conversation_id": conversation_id,
            "message_id": message_id,
        }

        resp = self.session.post(
            f"{self.BASE_URL}/backend-api/conversation",
            json=payload,
            stream=True
        )

        for line in resp.iter_lines():
            if line:
                line = line.decode("utf-8")
                if line.startswith("data: "):
                    data = line[6:]
                    if data != "[DONE]":
                        try:
                            yield json.loads(data)
                        except:
                            continue


# Example usage
if __name__ == "__main__":
    client = ChatGPTClient()

    # Test connection
    print("Testing connection...")
    try:
        me = client.get_me()
        print(f"Logged in as: {me.get('email', 'Unknown')}")

        models = client.get_models()
        print(f"Available models: {[m.get('slug') for m in models.get('models', [])]}")

        # Send a test message
        print("\\nSending test message...")
        full_response = ""
        for chunk in client.send_message("Hello! Just testing the connection."):
            if chunk.get("message", {}).get("content", {}).get("parts"):
                parts = chunk["message"]["content"]["parts"]
                if parts:
                    full_response = parts[0]

        print(f"Response: {full_response[:200]}...")

    except Exception as e:
        print(f"Error: {e}")
        print("Make sure you have valid session cookies/tokens")
`;

    fs.writeFileSync('chatgpt_client.py', pythonCode);
    console.log('✅ Saved Python client to chatgpt_client.py');
  }

  process.on('SIGINT', saveData);
  process.on('SIGTERM', saveData);

  // Navigate
  await page.goto('https://chatgpt.com/', { waitUntil: 'domcontentloaded', timeout: 60000 });

  console.log('\n✅ Page loaded!');
  console.log('');
  console.log('📋 INSTRUCTIONS:');
  console.log('   1. Log in to your ChatGPT account');
  console.log('   2. Send at least one message to capture the conversation API');
  console.log('   3. Try different features (model switching, etc.)');
  console.log('   4. Press Ctrl+C to save and generate API client');
  console.log('');

  // Keep alive
  await new Promise(() => {});
})();
